import sys
import os
import urllib.request
import zipfile
import shutil

# This URL should be replaced with your live Render URL once the server is deployed.
# e.g., "https://your-render-app.onrender.com"
RENDER_URL = "https://loanserve-incremental.onrender.com"

def download_and_extract(week: int):
    url = f"{RENDER_URL}/download/{week}"
    zip_path = "temp_download.zip"
    
    print(f"Downloading Week {week} code from {url}...")
    try:
        urllib.request.urlretrieve(url, zip_path)
    except Exception as e:
        print(f"Failed to download: {e}")
        return
        
    print("Extracting ZIP file...")
    
    # We want to extract without overwriting critical files.
    # The zip contains the entire directory structure.
    # We will ignore index.html, tests.py, dir_structure.txt, requirements.txt, sync.py
    protected_files = {"index.html", "tests.py", "dir_structure.txt", "requirements.txt", "sync.py"}
    
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        for member in zip_ref.namelist():
            # Extract only files (skip directories themselves, they get created automatically)
            if member.endswith('/'):
                continue
                
            filename = os.path.basename(member)
            
            # Protect files that exist in the root directory from being overwritten
            # If member path has no directory, it's in the root
            if '/' not in member and member in protected_files:
                print(f"Skipping protected file: {member}")
                continue
                
            # We skip overwriting tests.py no matter where it is, just in case
            if "tests.py" in member:
                continue
                
            # Extract and replace safely
            with zip_ref.open(member) as source:
                # Windows ZIPs contain backslashes. We must convert them to forward slashes for Linux.
                normalized_member = member.replace("\\", "/")
                
                # Extract into the actual Project directory where pytest runs
                target_root = os.path.join(os.getcwd(), "Project") if os.path.basename(os.getcwd()) != "Project" else os.getcwd()
                target_path = os.path.join(target_root, normalized_member)
                os.makedirs(os.path.dirname(target_path), exist_ok=True)
                
                with open(target_path, "wb") as target:
                    shutil.copyfileobj(source, target)
                
    # --- DESTRUCTION PHASE ---
    # Intentionally delete future code so that tests accurately fail for weeks you haven't reached yet
    print("Initiating destruction phase for future weeks...")
    
    # We must delete the code from the actual Project directory where pytest runs
    target_root = os.path.join(os.getcwd(), "Project") if os.path.basename(os.getcwd()) != "Project" else os.getcwd()
    search_dirs = [target_root]
    
    try:
        import loanserve
        installed_path = os.path.dirname(os.path.dirname(loanserve.__file__))
        if installed_path not in search_dirs:
            search_dirs.append(installed_path)
            print(f"Also destroying code in installed package: {installed_path}")
    except ImportError:
        pass
    
    def safe_delete(base_dir, path):
        full_path = os.path.join(base_dir, path)
        if os.path.exists(full_path):
            if os.path.isdir(full_path):
                shutil.rmtree(full_path)
            else:
                os.remove(full_path)
                
    for base in search_dirs:
        if week < 8:
            safe_delete(base, "loanserve/assistant")
        if week < 7:
            safe_delete(base, "loanserve/retrieval")
        if week < 6:
            safe_delete(base, "loanserve/message_intelligence/escalation.py")
            safe_delete(base, "loanserve/message_intelligence/batch_pipeline.py")
            safe_delete(base, "loanserve/message_intelligence/injection_guard.py")
        if week < 5:
            safe_delete(base, "loanserve/message_intelligence")
        if week < 2:
            safe_delete(base, "loanserve/api")
        if week < 3:
            safe_delete(base, "loanserve/data_access")
        if week < 2:
            safe_delete(base, "loanserve/risk_models")
        
    print("Destruction complete.")

    # --- ARTIFACT CLEANUP & REGENERATION ---
    print("\n--- ARTIFACT CLEANUP ---")
    print("Clearing stale artifacts, processed data, and outputs...")
    for folder_name in ["artifacts", "processed_data", "output"]:
        folder_path = os.path.join(target_root, folder_name)
        if os.path.exists(folder_path):
            for file in os.listdir(folder_path):
                file_path = os.path.join(folder_path, file)
                if os.path.isfile(file_path):
                    try:
                        os.remove(file_path)
                    except Exception as e:
                        pass
    print("Cleanup complete.")

    print("\n--- DATA & MODEL REGENERATION ---")
    print(f"Regenerating artifacts for Week {week}...")
    import subprocess
    scripts = []
    if week >= 2:
        scripts.extend([
            "loanserve.data_access.cleaning_pipeline",
            "loanserve.data_access.database_loader",
            "loanserve.data_access.database_reports"
        ])
    if week >= 3:
        scripts.extend(["loanserve.risk_models.baseline_model"])
    if week >= 4:
        scripts.extend([
            "loanserve.risk_models.feature_engineering",
            "loanserve.risk_models.tree_models",
            "loanserve.risk_models.cross_validation",
            "loanserve.risk_models.champion_model",
            "loanserve.risk_models.work_queue"
        ])
    if week >= 5:
        scripts.extend([
            "loanserve.message_intelligence.message_classifier",
            "loanserve.message_intelligence.thread_summary",
            "loanserve.message_intelligence.entity_extraction"
        ])
    if week >= 6:
        scripts.extend([
            "loanserve.message_intelligence.batch_pipeline",
            "loanserve.message_intelligence.injection_guard",
            "loanserve.message_intelligence.escalation"
        ])
    if week >= 7:
        scripts.extend(["loanserve.retrieval.vector_store"])

    for script in scripts:
        print(f"Running {script}...")
        try:
            subprocess.run([sys.executable, "-m", script], cwd=target_root, check=True)
        except Exception as e:
            print(f"Failed to run {script}: {e}")
    print("Regeneration complete.")

    # --- DEBUGGING PHASE ---
    print("\n--- DEBUG INFO ---")
    print("Checking if files actually exist on disk:")
    print(f"loanserve/assistant exists locally: {os.path.exists(os.path.join(os.getcwd(), 'loanserve', 'assistant'))}")
    
    print("\nChecking if Python can still import the deleted code:")
    try:
        import sys
        if 'loanserve.assistant.graph' in sys.modules:
            print("WARNING: loanserve.assistant.graph was already loaded in sys.modules!")
        
        import importlib
        import loanserve
        importlib.reload(loanserve) # Force reload
        try:
            import loanserve.assistant.graph
            print(f"FAILED TO DESTROY! Python successfully imported loanserve.assistant.graph from: {loanserve.assistant.graph.__file__}")
        except ImportError as e:
            print(f"SUCCESS: Python cannot import loanserve.assistant.graph. Error: {e}")
            
    except Exception as e:
        print(f"Debug error: {e}")
    print("------------------\n")

    # Remove conftest.py so we don't hide tests anymore. The UI expects all 183 to be reported.
    conftest_path = os.path.join(os.getcwd(), "conftest.py")
    if os.path.exists(conftest_path):
        os.remove(conftest_path)

    # Clean up the downloaded ZIP
    try:
        os.remove(zip_path)
    except PermissionError:
        print("Could not clean up temp_download.zip due to file lock. You can delete it manually.")
        
    print(f"Successfully synced workspace to Week {week} codebase!")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python sync.py <week_number>")
        print("Example: python sync.py 5")
        sys.exit(1)
        
    try:
        target_week = int(sys.argv[1])
        if target_week < 1 or target_week > 8:
            print("Week number must be between 1 and 8.")
            sys.exit(1)
            
        download_and_extract(target_week)
    except ValueError:
        print("Please provide a valid integer for the week number.")
