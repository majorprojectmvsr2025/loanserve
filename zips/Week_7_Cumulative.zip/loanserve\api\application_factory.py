"""loanserve/api/application_factory.py — Week 2 Day 3 through Week 3 Day 4

FastAPI application factory.  Each call returns a fresh, independent instance.
"""
import os
from typing import Optional

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi

from config import constants
from loanserve.api.access_control import AccessControl
from loanserve.api.middleware import RateLimitingMiddleware, RequestLoggingMiddleware
from loanserve.api.repository import InMemoryApplicationRepository, SqlApplicationRepository
from loanserve.api.routers import loan_applications, user_accounts
from loanserve.core.exceptions import LoanServeError


def create_application(
    database_url: Optional[str] = None,
    maximum_requests_per_minute: int = 60,
    request_log_path: Optional[str] = None,
) -> FastAPI:
    """Create and return a fully configured FastAPI instance.

    Parameters
    ----------
    database_url:
        SQLAlchemy database URL.  When ``None`` the service uses an in-memory
        store that is reset when the service stops.
    maximum_requests_per_minute:
        Per-IP request cap.
    request_log_path:
        Path to the request log file.  When ``None`` no log is written.
    """
    app = FastAPI(title="LoanServe API", version="1.0.0")

    # ------------------------------------------------------------------
    # State
    # ------------------------------------------------------------------

    if database_url is not None:
        from loanserve.api.orm_models import create_session_factory
        app.state.application_repository = SqlApplicationRepository(
            create_session_factory(database_url)
        )
    else:
        app.state.application_repository = InMemoryApplicationRepository()

    app.state.access_control = AccessControl()
    app.state.user_store: dict = {}

    # ------------------------------------------------------------------
    # CORS
    # ------------------------------------------------------------------

    app.add_middleware(
        CORSMiddleware,
        allow_origins=constants.ALLOWED_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ------------------------------------------------------------------
    # Rate limiting
    # ------------------------------------------------------------------

    app.add_middleware(RateLimitingMiddleware,
                       max_requests_per_minute=maximum_requests_per_minute)

    # ------------------------------------------------------------------
    # Request logging
    # ------------------------------------------------------------------

    if request_log_path is not None:
        app.add_middleware(RequestLoggingMiddleware, log_path=request_log_path)

    # ------------------------------------------------------------------
    # Domain error handler
    # ------------------------------------------------------------------

    from fastapi import Request
    from fastapi.responses import JSONResponse

    @app.exception_handler(LoanServeError)
    async def _loan_serve_error_handler(request: Request, exc: LoanServeError):
        return JSONResponse(status_code=400, content={"detail": str(exc)})

    # ------------------------------------------------------------------
    # Health check
    # ------------------------------------------------------------------

    @app.get("/health", tags=["meta"])
    def health():
        count = app.state.application_repository.count_applications()
        return {"status": "ok", "applications": count}

    # ------------------------------------------------------------------
    # Routers
    # ------------------------------------------------------------------

    app.include_router(loan_applications.router)
    app.include_router(user_accounts.router)

    # Week 8 Day 3
    try:
        from loanserve.api.routers import assistant
        app.include_router(assistant.router)
    except ImportError:
        pass

    # ------------------------------------------------------------------
    # Exception Handlers
    # ------------------------------------------------------------------
    from fastapi import Request
    from fastapi.responses import JSONResponse
    
    @app.exception_handler(LoanServeError)
    async def loanserve_error_handler(request: Request, exc: LoanServeError):
        return JSONResponse(status_code=400, content={"detail": str(exc)})


    # ------------------------------------------------------------------
    # Security scheme in OpenAPI (so Swagger /docs shows the padlock)
    # ------------------------------------------------------------------

    def _custom_openapi():
        if app.openapi_schema:
            return app.openapi_schema
        schema = get_openapi(
            title=app.title,
            version=app.version,
            routes=app.routes,
        )
        schema.setdefault("components", {}).setdefault("securitySchemes", {})
        schema["components"]["securitySchemes"]["BearerAuth"] = {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT",
        }
        app.openapi_schema = schema
        return schema

    app.openapi = _custom_openapi

    return app
