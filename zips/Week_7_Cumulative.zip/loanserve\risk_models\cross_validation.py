"""loanserve/risk_models/cross_validation.py — Week 4 Day 2"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC
from sklearn.calibration import CalibratedClassifierCV

from config import constants
from loanserve.risk_models.feature_pipeline import build_feature_pipeline, split_for_modelling

PROJECT_DIR = Path(__file__).resolve().parents[2]


def build_linear_svm() -> Pipeline:
    """Return an *unfitted* pipeline with a calibrated linear SVM as the estimator."""
    prep = build_feature_pipeline()
    svm = LinearSVC(max_iter=2000, class_weight="balanced",
                    random_state=constants.RANDOM_SEED)
    calibrated = CalibratedClassifierCV(svm, cv=3)
    return Pipeline(steps=prep.steps + [("model", calibrated)])


def every_model() -> dict:
    """Return a dict of four unfitted pipelines, one per candidate."""
    from loanserve.risk_models.baseline_model import load_model
    from loanserve.risk_models.tree_models import build_decision_tree, build_random_forest
    import sklearn
    import copy

    # Build fresh unfitted instances
    baseline_fitted = load_model(PROJECT_DIR / "artifacts" / "baseline_model.pkl")
    # We need unfitted clones
    from sklearn.base import clone as _c
    baseline_unfitted = _c(baseline_fitted)

    # For trees — rebuild pipeline scaffolds
    from sklearn.linear_model import LogisticRegression
    prep = build_feature_pipeline()
    lr = LogisticRegression(max_iter=1000, class_weight="balanced",
                            random_state=constants.RANDOM_SEED)
    logistic = Pipeline(steps=prep.steps + [("model", lr)])

    from sklearn.tree import DecisionTreeClassifier
    prep2 = build_feature_pipeline()
    dt_est = DecisionTreeClassifier(max_depth=8, class_weight="balanced",
                                    random_state=constants.RANDOM_SEED)
    dt = Pipeline(steps=prep2.steps + [("model", dt_est)])

    from sklearn.ensemble import RandomForestClassifier
    prep3 = build_feature_pipeline()
    rf_est = RandomForestClassifier(n_estimators=200, max_depth=10,
                                    class_weight="balanced",
                                    random_state=constants.RANDOM_SEED, n_jobs=-1)
    rf = Pipeline(steps=prep3.steps + [("model", rf_est)])

    return {
        "logistic_baseline": logistic,
        "decision_tree": dt,
        "random_forest": rf,
        "linear_svm": build_linear_svm(),
    }


def score_across_folds(model: Pipeline, X, y) -> dict:
    """Cross-validate *model* with stratified folds; return scores dict."""
    skf = StratifiedKFold(
        n_splits=constants.CROSS_VALIDATION_FOLDS,
        shuffle=True,
        random_state=constants.RANDOM_SEED,
    )
    import sklearn.clone as _clone_fn
    from sklearn import clone
    fold_scores = []
    for train_idx, val_idx in skf.split(X, y):
        X_tr, X_val = X.iloc[train_idx], X.iloc[val_idx]
        y_tr, y_val = y.iloc[train_idx], y.iloc[val_idx]
        cloned = clone(model)
        cloned.fit(X_tr, y_tr)
        score = roc_auc_score(y_val, cloned.predict_proba(X_val)[:, 1])
        fold_scores.append(round(float(score), 6))
    mean = round(float(np.mean(fold_scores)), 6)
    spread = round(float(max(fold_scores) - min(fold_scores)), 6)
    return {"fold_scores": fold_scores, "mean_roc_auc": mean, "spread": spread}


def training_against_holdout(model: Pipeline, cleaned_csv_path) -> tuple:
    """Fit on training split, return (training_roc_auc, holdout_roc_auc)."""
    X_train, X_holdout, y_train, y_holdout = split_for_modelling(cleaned_csv_path)
    model.fit(X_train, y_train)
    train_score = roc_auc_score(y_train, model.predict_proba(X_train)[:, 1])
    holdout_score = roc_auc_score(y_holdout, model.predict_proba(X_holdout)[:, 1])
    return round(float(train_score), 4), round(float(holdout_score), 4)


def run(project_dir: Path | None = None) -> None:
    base = project_dir or PROJECT_DIR
    (base / "output").mkdir(parents=True, exist_ok=True)
    cleaned_path = base / "processed_data" / "loan_applications_cleaned.csv"
    X_train, _, y_train, _ = split_for_modelling(cleaned_path)
    results = {}
    for name, model in every_model().items():
        print(f"Cross-validating {name}...")
        results[name] = score_across_folds(model, X_train, y_train)
    with open(base / "output" / "fold_scores.json", "w") as fh:
        json.dump(results, fh, indent=2)
    print("Fold scores written.")


if __name__ == "__main__":
    run()
