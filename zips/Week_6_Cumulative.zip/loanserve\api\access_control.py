"""loanserve/api/access_control.py — Week 3 Day 3-4

JWT issuance, verification, role authorisation and audit logging.
"""
import datetime
import os
from pathlib import Path

import jwt
from fastapi import HTTPException


class AccessControl:
    """Issue and verify signed JWT tokens; record an audit trail."""

    _ALGORITHM = "HS256"
    _TOKEN_LIFETIME_HOURS = 8

    def __init__(self):
        self._secret = os.environ.get("LOANSERVE_JWT_SECRET", "change-me-in-production")
        self._audit_path = Path(
            os.environ.get("LOANSERVE_AUDIT_LOG", "output/logs/audit.log")
        )

    # ------------------------------------------------------------------
    # Token management
    # ------------------------------------------------------------------

    def issue_token(self, username: str, role: str) -> str:
        """Return a signed JWT encoding *username*, *role* and an expiry."""
        payload = {
            "sub": username,
            "role": role,
            "exp": datetime.datetime.utcnow() + datetime.timedelta(
                hours=self._TOKEN_LIFETIME_HOURS
            ),
        }
        return jwt.encode(payload, self._secret, algorithm=self._ALGORITHM)

    def read_token(self, authorization: str) -> dict:
        """Decode and verify a Bearer token; raise 401 on any failure."""
        if not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="Bearer token required.")
        token = authorization[len("Bearer "):]
        try:
            return jwt.decode(token, self._secret, algorithms=[self._ALGORITHM])
        except jwt.PyJWTError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc

    # ------------------------------------------------------------------
    # Authorisation
    # ------------------------------------------------------------------

    _READ_METHODS = {"GET", "HEAD", "OPTIONS"}
    _WRITE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}
    _ADMIN_ONLY_METHODS = {"DELETE"}

    def authorise(self, request) -> dict:
        """Read the request's token; raise 401/403 if the holder lacks permission.

        Returns the decoded claims dict when authorisation succeeds.
        """
        auth_header = request.headers.get("Authorization", "")
        claims = self.read_token(auth_header)
        role = claims.get("role", "")
        if request.method in self._ADMIN_ONLY_METHODS and role != "administrator":
            raise HTTPException(
                status_code=403,
                detail="Only administrators may perform this action.",
            )
        return claims

    # ------------------------------------------------------------------
    # Audit trail
    # ------------------------------------------------------------------

    def record_audit_entry(self, username: str, action: str) -> None:
        """Append a timestamped entry to the audit log."""
        self._audit_path.parent.mkdir(parents=True, exist_ok=True)
        stamp = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        with open(self._audit_path, "a", encoding="utf-8") as fh:
            fh.write(f"{stamp} | {username} | {action}\n")
