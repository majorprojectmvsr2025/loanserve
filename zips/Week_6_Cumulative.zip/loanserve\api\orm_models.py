"""loanserve/api/orm_models.py — Week 2 Day 5

SQLAlchemy ORM: Applicant and StoredApplication with a one-to-many relationship,
plus a session factory that creates tables on first use.
"""
from contextlib import contextmanager
from typing import List

from sqlalchemy import (
    Float,
    ForeignKey,
    Integer,
    String,
    create_engine,
)
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    Session,
    mapped_column,
    relationship,
    sessionmaker,
)


class _Base(DeclarativeBase):
    pass


class Applicant(_Base):
    __tablename__ = "applicants"

    applicant_name: Mapped[str] = mapped_column(String, primary_key=True)

    applications: Mapped[List["StoredApplication"]] = relationship(
        "StoredApplication",
        back_populates="applicant",
        cascade="all, delete-orphan",
    )


class StoredApplication(_Base):
    __tablename__ = "stored_applications"

    application_id: Mapped[str] = mapped_column(String, primary_key=True)
    applicant_name: Mapped[str] = mapped_column(
        String, ForeignKey("applicants.applicant_name"), nullable=False
    )
    loan_type: Mapped[str] = mapped_column(String, nullable=False)
    pan_number: Mapped[str] = mapped_column(String, nullable=False)
    mobile_number: Mapped[str] = mapped_column(String, nullable=False)
    email_address: Mapped[str] = mapped_column(String, nullable=False)
    loan_amount_inr: Mapped[float] = mapped_column(Float, nullable=False)
    tenure_months: Mapped[int] = mapped_column(Integer, nullable=False)
    monthly_income_inr: Mapped[float] = mapped_column(Float, nullable=False)
    age_years: Mapped[int] = mapped_column(Integer, nullable=False)
    credit_score: Mapped[int] = mapped_column(Integer, nullable=False)
    collateral_value_inr: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)

    applicant: Mapped[Applicant] = relationship("Applicant", back_populates="applications")


def create_session_factory(database_url: str):
    """Create (and return) a session factory bound to *database_url*.

    Tables are created on first call so a fresh deployment needs no manual setup.
    Returns a context-manager factory (i.e. sessions are used as ``with factory() as s:``).
    """
    engine = create_engine(
        database_url,
        connect_args={"check_same_thread": False} if "sqlite" in database_url else {},
    )
    _Base.metadata.create_all(engine)
    return sessionmaker(bind=engine, class_=Session, expire_on_commit=False)
