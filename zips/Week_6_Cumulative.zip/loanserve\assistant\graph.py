"""loanserve/assistant/graph.py — Week 8 Day 2"""
from langgraph.graph import StateGraph, START, END
from loanserve.assistant.state import AssistantState
from loanserve.assistant import nodes

def still_going(state: AssistantState) -> str:
    """Return 'stop' if refused, else 'go'."""
    if state.get("refused"):
        return "stop"
    return "go"


def build_assistant_graph(checkpointer=None):
    """Build and compile the LangGraph for the assistant."""
    builder = StateGraph(AssistantState)
    
    # Add nodes
    builder.add_node("triage", nodes.triage)
    builder.add_node("plan", nodes.run_tools) # Placeholder for plan logic
    builder.add_node("tools", nodes.run_tools)
    builder.add_node("draft", nodes.draft)
    builder.add_node("approval", nodes.approval)
    builder.add_node("critic", nodes.critic)
    builder.add_node("respond", nodes.respond)
    
    # Add edges
    builder.add_edge(START, "triage")
    
    # Conditional edges for nodes that can refuse
    for node in ["triage", "plan", "draft", "critic"]:
        builder.add_conditional_edges(
            node,
            still_going,
            {"stop": END, "go": _next_node_for(node)}
        )
        
    builder.add_edge("tools", "draft")
    builder.add_edge("approval", "critic")
    builder.add_edge("respond", END)
    
    if checkpointer is None:
        from langgraph.checkpoint.memory import MemorySaver
        checkpointer = MemorySaver()
    
    return builder.compile(checkpointer=checkpointer)

def _next_node_for(node: str) -> str:
    mapping = {
        "triage": "plan",
        "plan": "tools",
        "draft": "approval",
        "critic": "respond"
    }
    return mapping[node]
