"""loanserve/risk_models/feature_pipeline.py — Week 3 Day 5

Shared preparation pipeline for all risk models.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from config import constants

PROJECT_DIR = Path(__file__).resolve().parents[2]


def select_modelling_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Return only the columns the models train on (no identifier, no target)."""
    cols = list(constants.NUMERIC_MODELLING_COLUMNS) + list(
        constants.CATEGORICAL_MODELLING_COLUMNS
    )
    return df[cols]


def build_feature_pipeline() -> Pipeline:
    """Return an unfitted sklearn Pipeline that prepares the modelling columns.

    Numeric columns: median imputation → standard scaling.
    Categorical columns: constant imputation → one-hot encoding.
    """
    numeric_transformer = Pipeline(steps=[
        ("impute", SimpleImputer(strategy="median")),
        ("scale", StandardScaler()),
    ])
    categorical_transformer = Pipeline(steps=[
        ("impute", SimpleImputer(strategy="constant", fill_value="missing")),
        ("encode", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ])
    preprocessor = ColumnTransformer(transformers=[
        ("num", numeric_transformer, list(constants.NUMERIC_MODELLING_COLUMNS)),
        ("cat", categorical_transformer, list(constants.CATEGORICAL_MODELLING_COLUMNS)),
    ])
    return Pipeline(steps=[("preprocessor", preprocessor)])


def split_for_modelling(cleaned_csv_path, test_size: float = 0.20):
    """Load the cleaned CSV and return (X_train, X_holdout, y_train, y_holdout).

    The split is always the same for the same file (fixed random seed) so
    models trained on different days can be compared on the same holdout.
    """
    df = pd.read_csv(cleaned_csv_path)
    X = select_modelling_columns(df)
    y = df[constants.TARGET_COLUMN]
    return train_test_split(X, y, test_size=test_size,
                            random_state=constants.RANDOM_SEED, stratify=y)
