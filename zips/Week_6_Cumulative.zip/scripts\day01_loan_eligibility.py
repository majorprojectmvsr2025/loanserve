#!/usr/bin/env python3
"""scripts/day01_loan_eligibility.py — Week 1 Day 1

Reads loan details from stdin and prints:
  - Monthly instalment
  - Total interest
  - Debt-to-income ratio
  - Repayment schedule (first 3 months)
  - Decision: APPROVED or REJECTED (with reason lines)
"""
import sys


# ---------------------------------------------------------------------------
# Product catalogue (inline for standalone script)
# ---------------------------------------------------------------------------

LOAN_PRODUCTS = {
    "home":     {"rate": 8.50,  "max_amount": 15_000_000},
    "vehicle":  {"rate": 9.75,  "max_amount":  2_000_000},
    "gold":     {"rate": 11.00, "max_amount":  1_500_000},
    "personal": {"rate": 14.50, "max_amount":  1_500_000},
}

MINIMUM_AGE = 21
MAXIMUM_AGE = 60
MAXIMUM_DTI = 0.50


# ---------------------------------------------------------------------------
# Core calculations
# ---------------------------------------------------------------------------

def calculate_monthly_installment(principal: float, annual_rate: float,
                                   tenure_months: int) -> float:
    """EMI = P * r * (1+r)^n / ((1+r)^n - 1), with r=0 handled separately."""
    if annual_rate == 0.0:
        return principal / tenure_months
    r = annual_rate / 100 / 12
    factor = (1 + r) ** tenure_months
    return principal * r * factor / (factor - 1)


def calculate_total_interest(emi: float, principal: float,
                              tenure_months: int) -> float:
    return emi * tenure_months - principal


def calculate_debt_to_income_ratio(emi: float, monthly_income: float) -> float:
    return emi / monthly_income


def repayment_schedule(principal: float, annual_rate: float,
                       tenure_months: int, rows: int = 3):
    """Yields (month, interest_component, principal_component, balance) tuples."""
    emi = calculate_monthly_installment(principal, annual_rate, tenure_months)
    r = annual_rate / 100 / 12
    balance = principal
    for month in range(1, rows + 1):
        interest_part = balance * r if annual_rate > 0 else 0.0
        principal_part = emi - interest_part
        balance -= principal_part
        yield month, interest_part, principal_part, balance


# ---------------------------------------------------------------------------
# Eligibility rules
# ---------------------------------------------------------------------------

def check_eligibility(loan_type: str, loan_amount: float, annual_rate: float,
                       tenure_months: int, monthly_income: float,
                       age_years: int):
    """Returns list of reason strings (empty = APPROVED)."""
    reasons = []

    if age_years < MINIMUM_AGE or age_years > MAXIMUM_AGE:
        reasons.append(
            f"Reason: Applicant age {age_years} is outside the permitted range "
            f"of {MINIMUM_AGE}–{MAXIMUM_AGE} years."
        )

    emi = calculate_monthly_installment(loan_amount, annual_rate, tenure_months)
    dti = calculate_debt_to_income_ratio(emi, monthly_income)
    if dti > MAXIMUM_DTI:
        reasons.append(
            f"Reason: Debt-to-income ratio {dti:.2f} exceeds the maximum of "
            f"{MAXIMUM_DTI:.2f}."
        )

    product = LOAN_PRODUCTS.get(loan_type.lower())
    if product is None:
        reasons.append(
            f"Reason: Loan type '{loan_type}' is not offered by LoanServe."
        )
    elif loan_amount > product["max_amount"]:
        reasons.append(
            f"Reason: Loan amount {loan_amount:.2f} exceeds the maximum of "
            f"{product['max_amount']:.2f} for a {loan_type.lower()} loan."
        )

    return reasons


# ---------------------------------------------------------------------------
# Main — read from stdin
# ---------------------------------------------------------------------------

def main():
    lines = sys.stdin.read().split()
    idx = 0

    loan_type = lines[idx]; idx += 1
    loan_amount = float(lines[idx]); idx += 1
    annual_rate = float(lines[idx]); idx += 1
    tenure_months = int(lines[idx]); idx += 1
    monthly_income = float(lines[idx]); idx += 1
    age_years = int(lines[idx]); idx += 1

    emi = calculate_monthly_installment(loan_amount, annual_rate, tenure_months)
    total_interest = calculate_total_interest(emi, loan_amount, tenure_months)
    dti = calculate_debt_to_income_ratio(emi, monthly_income)

    print(f"Monthly Instalment: {emi:.2f}")
    print(f"Total Interest: {total_interest:.2f}")
    print(f"Debt-to-Income: {dti:.2f}")
    print()
    print("Repayment Schedule (first 3 months):")
    for month, interest_part, principal_part, balance in repayment_schedule(
            loan_amount, annual_rate, tenure_months, rows=3):
        print(f"  Month {month}: Interest {interest_part:.2f}, "
              f"Principal {principal_part:.2f}, Balance {balance:.2f}")

    print()
    reasons = check_eligibility(
        loan_type, loan_amount, annual_rate, tenure_months,
        monthly_income, age_years)

    if reasons:
        print("Decision: REJECTED")
        for reason in reasons:
            print(reason)
    else:
        print("Decision: APPROVED")


if __name__ == "__main__":
    main()
