"""loanserve/data_access/file_storage.py — Week 1 Day 3 & Day 5

CSV-based storage for loan applications.
"""
import csv
import os
from pathlib import Path

from loanserve.core.entities import create_loan_application
from loanserve.core.exceptions import StorageError


class ApplicationFileStorage:
    """Store and load loan application records as CSV files in *base_directory*."""

    def __init__(self, base_directory: str):
        self._base = Path(base_directory)

    def _path(self, filename: str) -> Path:
        return self._base / filename

    # ------------------------------------------------------------------
    # Week 1 Day 3
    # ------------------------------------------------------------------

    def save_csv(self, records: list, filename: str) -> None:
        """Write *records* (list of dicts) to *filename* inside the base directory."""
        if not records:
            raise StorageError(
                "No application records were supplied — nothing was written."
            )
        path = self._path(filename)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=list(records[0]))
            writer.writeheader()
            writer.writerows(records)

    def load_csv(self, filename: str) -> list:
        """Return a list of dicts loaded from *filename*."""
        path = self._path(filename)
        if not path.exists():
            raise StorageError(
                f"File '{filename}' was not found in '{self._base}'."
            )
        with open(path, newline="", encoding="utf-8") as fh:
            return list(csv.DictReader(fh))

    # ------------------------------------------------------------------
    # Week 1 Day 5
    # ------------------------------------------------------------------

    def load_applications(self, filename: str) -> list:
        """Load CSV rows and convert each to a typed LoanApplication object."""
        raw = self.load_csv(filename)
        return [create_loan_application(row) for row in raw]
