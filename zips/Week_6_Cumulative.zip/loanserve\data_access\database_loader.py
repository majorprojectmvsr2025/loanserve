"""loanserve/data_access/database_loader.py — Week 2 Day 2

Load the cleaned CSV into a SQLite database and provide record lookup/delete.
Run as module: python -m loanserve.data_access.database_loader
"""
from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Optional

import pandas as pd

from loanserve.core.exceptions import StorageError

PROJECT_DIR = Path(__file__).resolve().parents[2]


class ApplicationDatabase:
    """Thin wrapper around a SQLite database of loan applications."""

    def __init__(self, database_path):
        self._db_path = Path(database_path)

    def _connect(self):
        return sqlite3.connect(self._db_path)

    def load_from_csv(self, csv_path) -> None:
        """Load all rows from *csv_path* into the loan_applications table."""
        csv_path = Path(csv_path)
        if not csv_path.exists():
            raise StorageError(f"Cleaned file not found: {csv_path}")
        df = pd.read_csv(csv_path)
        conn = self._connect()
        df.to_sql("loan_applications", conn, if_exists="replace", index=False)
        conn.commit()
        conn.close()

    def find_application(self, application_id: str) -> Optional[dict]:
        """Return the row as a dict, or ``None`` if not found."""
        conn = self._connect()
        cur = conn.execute(
            "SELECT * FROM loan_applications WHERE application_id = ?",
            (application_id,),
        )
        row = cur.fetchone()
        conn.close()
        if row is None:
            return None
        columns = [desc[0] for desc in cur.description]
        return dict(zip(columns, row))

    def delete_application(self, application_id: str) -> int:
        """Delete the row; return the number of rows removed (0 or 1)."""
        conn = self._connect()
        cur = conn.execute(
            "DELETE FROM loan_applications WHERE application_id = ?",
            (application_id,),
        )
        conn.commit()
        count = cur.rowcount
        conn.close()
        return count


def run(project_dir: Path | None = None) -> None:
    base = project_dir or PROJECT_DIR
    (base / "database").mkdir(parents=True, exist_ok=True)
    db = ApplicationDatabase(base / "database" / "loanserve.db")
    cleaned_path = base / "processed_data" / "loan_applications_cleaned.csv"
    db.load_from_csv(cleaned_path)
    print("Database written to database/loanserve.db")


if __name__ == "__main__":
    run()
