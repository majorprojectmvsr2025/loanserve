"""loanserve/retrieval/document_loader.py — Week 6 Day 5"""
import os
from pathlib import Path
from pypdf import PdfReader

def load_policy_documents(pdf_dir: Path | str) -> list[dict]:
    """Load all PDFs from the directory, joining pages into a single text string."""
    documents = []
    pdf_dir = Path(pdf_dir)
    
    for path in pdf_dir.glob("*.pdf"):
        doc_id = path.stem
        reader = PdfReader(str(path))
        pages_text = []
        for page in reader.pages:
            pages_text.append(page.extract_text() or "")
            
        full_text = "\n".join(pages_text)
        documents.append({
            "document_id": doc_id,
            "text": full_text
        })
        
    return documents
