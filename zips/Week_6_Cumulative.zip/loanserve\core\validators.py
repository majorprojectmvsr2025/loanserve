"""loanserve/core/validators.py — Week 1 Day 5

Field validators for PAN number, mobile number, and email address.
Each validator normalises the value and raises InvalidApplicationError on
a bad format.
"""
import re

from loanserve.core.exceptions import InvalidApplicationError


# ---------------------------------------------------------------------------
# PAN number  (format: AAAAA0000A — five letters, four digits, one letter)
# ---------------------------------------------------------------------------

_PAN_PATTERN = re.compile(r"^[A-Z]{5}[0-9]{4}[A-Z]$")


def validate_pan_number(value: str) -> str:
    """Normalise (strip + upper) and validate an Indian PAN number."""
    normalised = value.strip().upper()
    if not _PAN_PATTERN.match(normalised):
        raise InvalidApplicationError(
            f"'{value}' is not a valid PAN number.  "
            "Expected format: five letters, four digits, one letter (e.g. ABCDE1234F)."
        )
    return normalised


# ---------------------------------------------------------------------------
# Indian mobile number (10 digits, must start with 6-9)
# ---------------------------------------------------------------------------

def validate_mobile_number(value: str) -> str:
    """Strip spaces, validate that the result is a 10-digit Indian mobile number."""
    digits = value.replace(" ", "")
    if not re.match(r"^[6-9][0-9]{9}$", digits):
        raise InvalidApplicationError(
            f"'{value}' is not a valid Indian mobile number. "
            "Expected 10 digits starting with 6, 7, 8 or 9."
        )
    return digits


# ---------------------------------------------------------------------------
# Email address
# ---------------------------------------------------------------------------

_EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def validate_email_address(value: str) -> str:
    """Normalise (strip + lower) and do a minimal validity check."""
    normalised = value.strip().lower()
    if not _EMAIL_PATTERN.match(normalised):
        raise InvalidApplicationError(
            f"'{value}' is not a valid email address."
        )
    return normalised
