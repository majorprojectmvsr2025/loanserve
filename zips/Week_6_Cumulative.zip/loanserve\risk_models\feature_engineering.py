"""loanserve/risk_models/feature_engineering.py — Week 4 Day 3"""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from config import constants

PROJECT_DIR = Path(__file__).resolve().parents[2]


def add_engineered_features(df: pd.DataFrame) -> pd.DataFrame:
    """Return a copy of *df* with new numeric and categorical columns derived."""
    from loanserve.core.loan_calculations import calculate_monthly_installment

    out = df.copy()

    # 1. Monthly installment
    rates = out["loan_type"].map(
        lambda t: constants.LOAN_PRODUCTS.get(t.lower(), {}).get("rate", 0.0)
    )
    # Vectorised installment calculation
    # EMI = P * r * (1+r)^n / ((1+r)^n - 1)
    r = rates / 100 / 12
    factor = (1 + r) ** out["tenure_months"]
    # Handle r=0 safely
    nonzero = r > 0
    emi = pd.Series(0.0, index=out.index)
    if nonzero.any():
        emi[nonzero] = (
            out.loc[nonzero, "loan_amount_inr"] * r[nonzero] * factor[nonzero]
        ) / (factor[nonzero] - 1)
    if (~nonzero).any():
        emi[~nonzero] = out.loc[~nonzero, "loan_amount_inr"] / out.loc[~nonzero, "tenure_months"]
    
    out["monthly_installment_inr"] = emi

    # 2. Installment to income ratio
    out["installment_to_income"] = emi / out["monthly_income_inr"]

    # 3. Credit band
    out["credit_band"] = pd.cut(
        out["credit_score"],
        bins=constants.CREDIT_BAND_CUTS,
        labels=constants.CREDIT_BAND_NAMES,
        include_lowest=True,
    ).astype(str)

    return out


def default_rate_by_band(enriched_csv_path) -> dict:
    """Return {band_name: default_rate} from the enriched CSV."""
    df = pd.read_csv(enriched_csv_path)
    rates = df.groupby("credit_band")[constants.TARGET_COLUMN].mean().to_dict()
    return {str(k): round(float(v), 4) for k, v in rates.items()}


def run(project_dir: Path | None = None) -> None:
    base = project_dir or PROJECT_DIR
    (base / "processed_data").mkdir(parents=True, exist_ok=True)
    
    for filename in ("loan_applications_cleaned.csv", "loan_applications_predict_cleaned.csv"):
        in_path = base / "processed_data" / filename
        out_path = base / "processed_data" / filename.replace("_cleaned", "_enriched")
        
        df = pd.read_csv(in_path)
        enriched = add_engineered_features(df)
        enriched.to_csv(out_path, index=False)
        print(f"Written {out_path.name} with {len(enriched.columns)} columns.")

if __name__ == "__main__":
    run()
