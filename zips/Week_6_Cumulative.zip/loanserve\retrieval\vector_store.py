"""loanserve/retrieval/vector_store.py — Week 7 Day 1"""
from __future__ import annotations

import json
from pathlib import Path
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer

from loanserve.retrieval.document_loader import load_policy_documents
from loanserve.retrieval.chunking import chunk_documents
from config import constants

PROJECT_DIR = Path(__file__).resolve().parents[2]


def open_policy_store(store_path: Path | str) -> chromadb.Collection:
    """Open or create the policy vector store with cosine distance."""
    client = chromadb.PersistentClient(path=str(store_path), settings=Settings(anonymized_telemetry=False))
    collection = client.get_or_create_collection(
        name="policies",
        metadata={"hnsw:space": "cosine"}
    )
    return collection


def describe_chunks(chunks: list[dict], manifest_path: Path | str) -> list[dict]:
    """Attach metadata (product_type, category, effective_date, document_id, heading) to chunks."""
    with open(manifest_path, "r", encoding="utf-8") as f:
        manifest_list = json.load(f)
        
    manifest = {item["document_id"]: item for item in manifest_list}
    
    descriptions = []
    for chunk in chunks:
        doc_info = manifest[chunk["document_id"]]
        descriptions.append({
            "product_type": doc_info["product_type"],
            "category": doc_info["category"],
            "effective_date": doc_info["effective_date"],
            "document_id": chunk["document_id"],
            "heading": chunk["heading"]
        })
    return descriptions


def load_embedder() -> SentenceTransformer:
    """Load the sentence transformer model."""
    return SentenceTransformer("all-MiniLM-L6-v2")


def search_policy(collection: chromadb.Collection, question: str, embedder: SentenceTransformer, how_many: int = 3) -> list[dict]:
    """Embed the question and search the collection for the closest chunks."""
    question_vector = embedder.encode(question, normalize_embeddings=True).tolist()
    
    results = collection.query(
        query_embeddings=[question_vector],
        n_results=how_many,
        include=["metadatas", "documents", "distances"]
    )
    
    found = []
    if results["ids"] and results["ids"][0]:
        for idx in range(len(results["ids"][0])):
            found.append({
                "chunk_id": results["ids"][0][idx],
                "text": results["documents"][0][idx],
                "heading": results["metadatas"][0][idx]["heading"],
                "document_id": results["metadatas"][0][idx]["document_id"],
                "distance": results["distances"][0][idx]
            })
            
    return found


def run(project_dir: Path | None = None) -> None:
    base = project_dir or PROJECT_DIR
    store_path = base / "database" / "policy_store"
    store_path.mkdir(parents=True, exist_ok=True)
    
    # Reload from scratch
    try:
        client = chromadb.PersistentClient(path=str(store_path))
        client.delete_collection("policies")
    except Exception:
        pass
        
    collection = open_policy_store(store_path)
    
    documents = load_policy_documents(base / "data" / "policy_documents")
    chunks = chunk_documents(documents, constants.POLICY_CHUNK_CHARACTERS)
    metadatas = describe_chunks(chunks, base / "data" / "policy_documents_manifest.json")
    
    embedder = load_embedder()
    
    # Encode and insert in batches
    batch_size = 100
    for i in range(0, len(chunks), batch_size):
        batch_chunks = chunks[i:i + batch_size]
        batch_texts = [c["text"] for c in batch_chunks]
        batch_ids = [c["chunk_id"] for c in batch_chunks]
        batch_metadatas = metadatas[i:i + batch_size]
        
        batch_embeddings = embedder.encode(batch_texts, normalize_embeddings=True).tolist()
        
        collection.add(
            ids=batch_ids,
            embeddings=batch_embeddings,
            metadatas=batch_metadatas,
            documents=batch_texts
        )
        
    print(f"Stored {collection.count()} chunks in the policy store")


if __name__ == "__main__":
    run()
