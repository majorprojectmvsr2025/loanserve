"""loanserve/data_access/database_reports.py — Week 2 Day 2

Aggregate reports from the loan application database.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import List


class DatabaseReports:
    """Run aggregate queries against the loanserve.db SQLite database."""

    def __init__(self, database_path):
        self._db_path = Path(database_path)

    def _connect(self):
        return sqlite3.connect(self._db_path)

    def default_rate_by_product(self) -> List[dict]:
        """Return one row per loan type, ordered alphabetically, with:
        - loan_type
        - applications  (count)
        - default_rate  (round to 4 dp)
        """
        sql = """
            SELECT
                loan_type,
                COUNT(*) AS applications,
                ROUND(CAST(SUM(defaulted) AS REAL) / COUNT(*), 4) AS default_rate
            FROM loan_applications
            GROUP BY loan_type
            ORDER BY loan_type
        """
        conn = self._connect()
        cur = conn.execute(sql)
        rows = [{"loan_type": r[0], "applications": r[1], "default_rate": r[2]}
                for r in cur.fetchall()]
        conn.close()
        return rows

    def volume_by_year(self) -> List[dict]:
        """Return one row per application year, ordered oldest first, with:
        - application_year  (string)
        - applications  (count)
        """
        sql = """
            SELECT
                SUBSTR(application_date, 1, 4) AS application_year,
                COUNT(*) AS applications
            FROM loan_applications
            GROUP BY application_year
            ORDER BY application_year
        """
        conn = self._connect()
        cur = conn.execute(sql)
        rows = [{"application_year": r[0], "applications": r[1]}
                for r in cur.fetchall()]
        conn.close()
        return rows

    def exposure_by_city(self, minimum_applications: int = 0) -> List[dict]:
        """Return one row per city with at least *minimum_applications*, ordered by
        total_amount_inr descending.
        """
        sql = """
            SELECT
                applicant_city,
                COUNT(*) AS applications,
                SUM(loan_amount_inr) AS total_amount_inr
            FROM loan_applications
            GROUP BY applicant_city
            HAVING COUNT(*) >= ?
            ORDER BY total_amount_inr DESC
        """
        conn = self._connect()
        cur = conn.execute(sql, (minimum_applications,))
        rows = [{"applicant_city": r[0], "applications": r[1], "total_amount_inr": r[2]}
                for r in cur.fetchall()]
        conn.close()
        return rows
