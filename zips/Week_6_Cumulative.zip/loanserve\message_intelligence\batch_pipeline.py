"""loanserve/message_intelligence/batch_pipeline.py — Week 6 Day 2"""
from __future__ import annotations

from pathlib import Path
import pandas as pd
import joblib

from loanserve.data_access.database_loader import ApplicationDatabase
from loanserve.message_intelligence.message_classifier import classify_message
from loanserve.message_intelligence.entity_extraction import (
    extract_references, extract_amounts, extract_dates, link_references
)

PROJECT_DIR = Path(__file__).resolve().parents[2]


class UnusableMessage(Exception):
    pass


def check_message(text: str | float | None) -> None:
    """Raise UnusableMessage if the message cannot be read."""
    if text is None or not isinstance(text, str):
        raise UnusableMessage("Not a string")
    
    if not text.strip():
        raise UnusableMessage("Message is blank")
        
    if len(text) > 4000:
        raise UnusableMessage("Message is too long")
        
    if "" in text or "\ufffd" in text:
        raise UnusableMessage("Message contains replacement characters")


def process_message(text: str, models: dict, database: ApplicationDatabase) -> dict:
    """Process a raw message, classify it, and extract entities."""
    check_message(text)
    
    from loanserve.message_intelligence.injection_guard import is_safe_to_send, find_injection_markers
    if not is_safe_to_send(text):
        markers = find_injection_markers(text)
        raise UnusableMessage(f"Injection attempt detected: {markers}")
    
    # Classify message (classification pipeline cleans text internally)
    classification = classify_message(models, text)
    
    # Extract entities from the RAW message
    refs = extract_references(text)
    found, not_found = link_references(refs, database)
    
    amounts = extract_amounts(text)
    dates = extract_dates(text)
    
    return {
        "category": classification["category"],
        "urgency": classification["urgency"],
        "references_found": " ".join(found),
        "references_not_found": " ".join(not_found),
        "amounts": " ".join(str(a) for a in amounts),
        "dates": " ".join(dates)
    }


def run(project_dir: Path | None = None) -> None:
    base = project_dir or PROJECT_DIR
    (base / "output").mkdir(parents=True, exist_ok=True)
    
    raw = pd.read_csv(base / "data" / "customer_messages.csv")
    database = ApplicationDatabase(base / "database" / "loanserve.db")
    models = joblib.load(base / "artifacts" / "message_classifier.pkl")
    
    results = []
    for idx, row in raw.iterrows():
        msg_id = str(row["message_id"])
        text = row["message_text"]
        
        try:
            processed = process_message(text, models, database)
            results.append({
                "message_id": msg_id,
                "status": "processed",
                "failure": "",
                "category": processed["category"],
                "urgency": processed["urgency"],
                "references_found": processed["references_found"],
                "references_not_found": processed["references_not_found"],
                "amounts": processed["amounts"],
                "dates": processed["dates"],
            })
        except UnusableMessage as exc:
            results.append({
                "message_id": msg_id,
                "status": "failed",
                "failure": str(exc),
                "category": "",
                "urgency": "",
                "references_found": "",
                "references_not_found": "",
                "amounts": "",
                "dates": "",
            })
            
    out = pd.DataFrame(results)
    out_path = base / "output" / "message_pipeline.csv"
    out.to_csv(out_path, index=False)
    print(f"Written pipeline output for {len(out)} messages to {out_path.name}")


if __name__ == "__main__":
    run()
