"""loanserve/message_intelligence/message_classifier.py — Week 5 Day 2"""
from __future__ import annotations

import joblib
from pathlib import Path
import pandas as pd

from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

from config import constants
from loanserve.message_intelligence.text_cleaning import clean_message

PROJECT_DIR = Path(__file__).resolve().parents[2]


def build_message_classifier() -> Pipeline:
    """Return an unfitted Pipeline for message classification."""
    vectoriser = TfidfVectorizer(
        preprocessor=clean_message,
        min_df=5,
        max_df=0.5,
    )
    # Using LogisticRegression as baseline classifier
    classifier = LogisticRegression(
        max_iter=1000, 
        class_weight="balanced", 
        random_state=constants.RANDOM_SEED
    )
    return Pipeline(steps=[("vectorise", vectoriser), ("classify", classifier)])


def labelled_messages(csv_path: str | Path) -> pd.DataFrame:
    """Return messages that have a category and urgency label."""
    df = pd.read_csv(csv_path)
    return df.dropna(subset=["category", "urgency"]).copy()


def classify_message(models: dict, message_text: str) -> dict:
    """Classify a single raw message."""
    category = models["category"].predict([message_text])[0]
    urgency = models["urgency"].predict([message_text])[0]
    return {"category": category, "urgency": urgency}


def run(project_dir: Path | None = None) -> None:
    base = project_dir or PROJECT_DIR
    (base / "artifacts").mkdir(parents=True, exist_ok=True)
    
    corpus = labelled_messages(base / "data" / "customer_messages.csv")
    
    cat_model = build_message_classifier()
    cat_model.fit(corpus["message_text"], corpus["category"])
    
    urg_model = build_message_classifier()
    urg_model.fit(corpus["message_text"], corpus["urgency"])
    
    models = {"category": cat_model, "urgency": urg_model}
    
    out_path = base / "artifacts" / "message_classifier.pkl"
    joblib.dump(models, out_path)
    print(f"Saved message classifiers to {out_path.name}")


if __name__ == "__main__":
    run()
