"""loanserve/retrieval/grounded_answer.py — Week 7 Day 2"""
import re
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[2]


class UngroundedAnswer(Exception):
    """Raised when an answer cites passages it was not given, or cites nothing at all."""
    pass


def cited_chunk_ids(answer: str) -> list[str]:
    """Extract citations like [CH00007] from the answer."""
    # Find all [CH...] strings
    matches = re.findall(r"\[CH\d{5}\]", answer)
    # Remove brackets
    ids = [m.strip("[]") for m in matches]
    
    # Deduplicate while preserving order
    seen = set()
    ordered_ids = []
    for chunk_id in ids:
        if chunk_id not in seen:
            seen.add(chunk_id)
            ordered_ids.append(chunk_id)
            
    return ordered_ids


def check_citations(answer: str, retrieved_chunks: list[dict]) -> list[str]:
    """Check that all cited chunks were actually retrieved."""
    citations = cited_chunk_ids(answer)
    if not citations:
        raise UngroundedAnswer("Answer does not cite any passages.")
        
    retrieved_ids = {chunk["chunk_id"] for chunk in retrieved_chunks}
    for chunk_id in citations:
        if chunk_id not in retrieved_ids:
            raise UngroundedAnswer(f"Cited passage {chunk_id} was not retrieved.")
            
    return citations


def build_prompt(question: str, retrieved_chunks: list[dict]) -> str:
    """Build a prompt containing the question and the retrieved passages with their IDs."""
    prompt_parts = ["Please answer the customer's question using ONLY the following passages.\n"]
    prompt_parts.append("Passages:")
    for chunk in retrieved_chunks:
        prompt_parts.append(f"[{chunk['chunk_id']}]\n{chunk['text']}")
        
    prompt_parts.append("\nQuestion:")
    prompt_parts.append(question)
    
    return "\n\n".join(prompt_parts)
