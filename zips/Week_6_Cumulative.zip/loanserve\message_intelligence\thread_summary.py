"""loanserve/message_intelligence/thread_summary.py — Week 5 Day 4"""
from __future__ import annotations

import re
from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

from loanserve.message_intelligence.text_cleaning import clean_message
from loanserve.message_intelligence.attention import scaled_dot_product_attention

PROJECT_DIR = Path(__file__).resolve().parents[2]


def split_into_sentences(messages: list[str] | pd.Series) -> list[str]:
    """Clean, lowercase, and split messages into sentences."""
    sentences = []
    for msg in messages:
        cleaned = clean_message(msg).lower()
        if not cleaned:
            continue
        # Split on ., ?, ! followed by space or end
        parts = re.split(r"(?<=[.!?])\s+|(?<=[.!?])$", cleaned)
        for part in parts:
            if part.strip():
                sentences.append(part.strip())
    return sentences


def score_sentences(sentences: list[str]) -> np.ndarray:
    """Score sentences by how much attention they receive from the rest of the thread."""
    if not sentences:
        return np.array([])
    if len(sentences) == 1:
        return np.array([1.0])
        
    vectoriser = TfidfVectorizer()
    vectors = vectoriser.fit_transform(sentences).toarray()
    
    # Self-attention: sentences are queries, keys, and values
    _, weights = scaled_dot_product_attention(vectors, vectors, vectors)
    
    # A sentence's score is the total attention it received from all sentences
    return weights.sum(axis=0)


def summarise_thread(messages: list[str] | pd.Series, max_sentences: int) -> list[str]:
    """Return the highest-scoring sentences in their original writing order."""
    sentences = split_into_sentences(messages)
    if len(sentences) <= max_sentences:
        return sentences
        
    scores = score_sentences(sentences)
    
    # Get indices of top max_sentences scores
    # argsort sorts ascending, so take the last max_sentences elements
    top_indices = np.argsort(scores)[-max_sentences:]
    
    # Sort indices back to writing order
    top_indices = sorted(top_indices)
    
    return [sentences[i] for i in top_indices]


def run(project_dir: Path | None = None) -> None:
    base = project_dir or PROJECT_DIR
    (base / "output").mkdir(parents=True, exist_ok=True)
    
    threads = pd.read_csv(base / "data" / "message_threads.csv")
    threads = threads.sort_values(["thread_id", "turn"])
    
    summaries = []
    for thread_id, group in threads.groupby("thread_id"):
        kept = summarise_thread(group["message_text"], 3)
        summaries.append({
            "thread_id": thread_id,
            "messages": len(group),
            "sentences": len(split_into_sentences(group["message_text"])),
            "summary": " ".join(kept)
        })
    
    out = pd.DataFrame(summaries)
    out_path = base / "output" / "thread_summaries.csv"
    out.to_csv(out_path, index=False)
    print(f"Written summaries for {len(out)} threads to {out_path.name}")


if __name__ == "__main__":
    run()
