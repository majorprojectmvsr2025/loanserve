"""loanserve/message_intelligence/llm_client.py — Week 5 Day 5"""
import json
import os
from pathlib import Path
import hashlib

from config import constants

PROJECT_DIR = Path(__file__).resolve().parents[2]


class LanguageModelError(Exception):
    """Raised when the LLM is misconfigured or fails."""
    pass


PROMPT_TEMPLATE = """
Please read the following conversation and extract the requested fields.

Conversation:
{summary}

You must return a JSON object containing EXACTLY these keys:
- "intent": The customer's primary goal.
- "key_facts": A list of extracted facts.
- "sentiment": A brief string classifying the customer's sentiment.
- "suggested_action": A brief action item.

Return only valid JSON. Do not include markdown formatting.
"""

REMINDER = "Your previous response was missing required keys. Please return a JSON object with exactly the requested keys."


def load_settings() -> tuple[str, str]:
    """Load GEMINI_API_KEY and GEMINI_MODEL from environment."""
    key = os.environ.get("GEMINI_API_KEY", "")
    model = os.environ.get("GEMINI_MODEL", "")
    
    if not key or not model:
        raise LanguageModelError("GEMINI_API_KEY and GEMINI_MODEL must be set in the environment.")
    
    return key, model


def read_answer(reply: str, keys: list[str] | None = None) -> dict:
    """Parse JSON reply and ensure all required keys are present."""
    if keys is None:
        keys = constants.LLM_REQUIRED_KEYS
        
    # Strip markdown fences if present
    cleaned = reply.strip()
    if cleaned.startswith("```json"):
        cleaned = cleaned[len("```json"):]
    if cleaned.startswith("```"):
        cleaned = cleaned[len("```"):]
    if cleaned.endswith("```"):
        cleaned = cleaned[:-3]
    cleaned = cleaned.strip()
    
    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Could not decode JSON: {exc}") from exc
        
    for key in keys:
        if key not in parsed:
            raise ValueError(f"Missing required key: {key}")
            
    return parsed


def cache_key(model_name: str, prompt: str) -> str:
    """Return a deterministic cache key for the model and prompt."""
    combined = f"{model_name}:{prompt}"
    return hashlib.sha256(combined.encode("utf-8")).hexdigest()
