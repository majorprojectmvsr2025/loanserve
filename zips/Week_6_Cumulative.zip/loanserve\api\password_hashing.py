"""loanserve/api/password_hashing.py — Week 3 Day 2"""
import bcrypt


class PasswordVault:
    """bcrypt-based password storage.  Each hash includes a unique salt."""

    def hash_password(self, plaintext: str) -> str:
        """Return a bcrypt hash with a freshly generated salt."""
        return bcrypt.hashpw(plaintext.encode(), bcrypt.gensalt()).decode()

    def matches_stored_hash(self, plaintext: str, stored_hash: str) -> bool:
        """Return ``True`` iff *plaintext* matches *stored_hash*."""
        try:
            return bcrypt.checkpw(plaintext.encode(), stored_hash.encode())
        except Exception:
            return False
