"""loanserve/core/loan_calculations.py — Week 1 Day 3

Core financial calculations moved from scripts/ into the loanserve package.
"""
import functools

import numpy as np

from loanserve.core.exceptions import InvalidApplicationError


# ---------------------------------------------------------------------------
# Validation decorator
# ---------------------------------------------------------------------------

def _validate_installment_inputs(func):
    """Refuse a negative/zero principal or zero-or-negative tenure."""
    @functools.wraps(func)
    def wrapper(principal: float, annual_rate: float, tenure_months: int):
        if principal < 0:
            raise InvalidApplicationError(
                f"Principal must be non-negative; got {principal}."
            )
        if tenure_months <= 0:
            raise InvalidApplicationError(
                f"Tenure must be a positive number of months; got {tenure_months}."
            )
        return func(principal, annual_rate, tenure_months)
    return wrapper


# ---------------------------------------------------------------------------
# Pure calculations
# ---------------------------------------------------------------------------

@_validate_installment_inputs
def calculate_monthly_installment(principal: float, annual_rate: float,
                                   tenure_months: int) -> float:
    """Standard EMI formula; handles zero interest rate."""
    if annual_rate == 0.0:
        return principal / tenure_months
    r = annual_rate / 100 / 12
    factor = (1 + r) ** tenure_months
    return principal * r * factor / (factor - 1)


def calculate_debt_to_income_ratio(monthly_installment: float,
                                    monthly_income: float) -> float:
    """Return the ratio of instalment to income."""
    return monthly_installment / monthly_income


def build_outstanding_balances(principal: float, annual_rate: float,
                                tenure_months: int) -> np.ndarray:
    """Return a NumPy array of outstanding balances after each instalment.

    Computed without a Python loop — uses a vectorised formula so a 300-month
    home loan does not require 300 iterations.
    """
    emi = calculate_monthly_installment(principal, annual_rate, tenure_months)

    if annual_rate == 0.0:
        # Simple equal reduction
        periods = np.arange(1, tenure_months + 1)
        return np.maximum(principal - emi * periods, 0.0)

    r = annual_rate / 100 / 12
    periods = np.arange(1, tenure_months + 1)
    # Standard outstanding-balance formula:
    # B(n) = P*(1+r)^n - EMI * ((1+r)^n - 1) / r
    factor = (1 + r) ** periods
    balances = principal * factor - emi * (factor - 1) / r
    return np.maximum(balances, 0.0)
