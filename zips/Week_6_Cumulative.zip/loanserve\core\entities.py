"""loanserve/core/entities.py — Week 1 Day 4

Domain entities: base LoanApplication, two concrete subclasses and a factory.
"""
import sys

from config import constants
from loanserve.core.exceptions import UnsupportedLoanTypeError
from loanserve.core.loan_calculations import (
    calculate_debt_to_income_ratio,
    calculate_monthly_installment,
)


# ---------------------------------------------------------------------------
# Base class
# ---------------------------------------------------------------------------

class LoanApplication:
    """Encapsulates a loan application and shared eligibility rules."""

    def __init__(self, record: dict):
        loan_type_raw = record.get("loan_type", "")
        loan_type = loan_type_raw.lower()

        if loan_type not in constants.LOAN_PRODUCTS:
            raise UnsupportedLoanTypeError(
                f"'{loan_type}' is not a loan type offered by LoanServe."
            )

        product = constants.LOAN_PRODUCTS[loan_type]

        self.loan_type = loan_type
        self.principal_inr = float(record.get("loan_amount_inr", 0))
        self.tenure_months = int(record.get("tenure_months", 0))
        self.monthly_income_inr = float(record.get("monthly_income_inr", 0))
        self.age_years = int(record.get("age_years", 0))
        self._product = product

    def interest_rate_percent(self) -> float:
        return self._product["rate"]

    def monthly_installment_inr(self) -> float:
        return calculate_monthly_installment(
            self.principal_inr,
            self.interest_rate_percent(),
            self.tenure_months,
        )

    def _base_rejection_reasons(self) -> list:
        reasons = []

        # Age rule
        if (self.age_years < constants.MINIMUM_AGE_YEARS
                or self.age_years > constants.MAXIMUM_AGE_YEARS):
            reasons.append(
                f"Applicant age {self.age_years} is outside the permitted range "
                f"of {constants.MINIMUM_AGE_YEARS}–{constants.MAXIMUM_AGE_YEARS} years."
            )

        # Affordability rule
        dti = calculate_debt_to_income_ratio(
            self.monthly_installment_inr(), self.monthly_income_inr)
        if dti > constants.MAXIMUM_DEBT_TO_INCOME_RATIO:
            reasons.append(
                f"Debt-to-income {dti:.2f} exceeds "
                f"{constants.MAXIMUM_DEBT_TO_INCOME_RATIO:.2f}."
            )

        # Product cap
        if self.principal_inr > self._product["max_amount"]:
            reasons.append(
                f"Loan amount {self.principal_inr:,.2f} exceeds the "
                f"{self.loan_type} cap of {self._product['max_amount']:,.2f}."
            )

        return reasons

    def rejection_reasons(self) -> list:
        return self._base_rejection_reasons()

    def is_eligible(self) -> bool:
        return len(self.rejection_reasons()) == 0


# ---------------------------------------------------------------------------
# Secured subclass — adds loan-to-value rule
# ---------------------------------------------------------------------------

class SecuredLoanApplication(LoanApplication):
    """Loan backed by collateral (home, vehicle, gold)."""

    def __init__(self, record: dict):
        super().__init__(record)
        self.collateral_value_inr = float(record.get("collateral_value_inr", 0))

    def loan_to_value_ratio(self) -> float:
        if self.collateral_value_inr == 0:
            return float("inf")
        return self.principal_inr / self.collateral_value_inr

    def rejection_reasons(self) -> list:
        reasons = self._base_rejection_reasons()
        if self.loan_to_value_ratio() > constants.MAXIMUM_LOAN_TO_VALUE_RATIO:
            reasons.append(
                f"Loan-to-value ratio {self.loan_to_value_ratio():.2f} exceeds "
                f"the maximum of {constants.MAXIMUM_LOAN_TO_VALUE_RATIO:.2f}."
            )
        return reasons


# ---------------------------------------------------------------------------
# Unsecured subclass — adds credit-score rule
# ---------------------------------------------------------------------------

class UnsecuredLoanApplication(LoanApplication):
    """Loan without collateral (personal)."""

    def __init__(self, record: dict):
        super().__init__(record)
        self.credit_score = int(record.get("credit_score", 0))

    def rejection_reasons(self) -> list:
        reasons = self._base_rejection_reasons()
        if self.credit_score < constants.MINIMUM_CREDIT_SCORE:
            reasons.append(
                f"Credit score {self.credit_score} is below the minimum of "
                f"{constants.MINIMUM_CREDIT_SCORE} for an unsecured loan."
            )
        return reasons


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def create_loan_application(record: dict) -> LoanApplication:
    """Return SecuredLoanApplication or UnsecuredLoanApplication based on type."""
    loan_type = record.get("loan_type", "").lower()

    if loan_type not in constants.LOAN_PRODUCTS:
        raise UnsupportedLoanTypeError(
            f"'{loan_type}' is not a loan type offered by LoanServe."
        )

    if constants.LOAN_PRODUCTS[loan_type]["secured"]:
        return SecuredLoanApplication(record)
    return UnsecuredLoanApplication(record)
