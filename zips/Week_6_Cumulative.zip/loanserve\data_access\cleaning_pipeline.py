"""loanserve/data_access/cleaning_pipeline.py — Week 2 Day 1

Clean the raw loan-application training and prediction files.
Run as a module: python -m loanserve.data_access.cleaning_pipeline
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

PROJECT_DIR = Path(__file__).resolve().parents[2]

# ── Rejection-reason priority order ───────────────────────────────────────────

_REQUIRED_FIELDS = [
    "application_id", "applicant_name", "loan_type", "loan_amount_inr",
    "tenure_months", "monthly_income_inr", "age_years", "credit_score",
    "application_date", "employment_type", "applicant_city",
]

_EMPLOYMENT_CANONICAL = {
    "salaried - government": "salaried_government",
    "salaried government": "salaried_government",
    "salaried_gov": "salaried_government",
    "gov salaried": "salaried_government",
    "salaried - private": "salaried_private",
    "salaried private": "salaried_private",
    "salaried_pvt": "salaried_private",
    "pvt salaried": "salaried_private",
    "self employed - business": "self_employed_business",
    "self employed business": "self_employed_business",
    "self-employed business": "self_employed_business",
    "self_employed business": "self_employed_business",
    "business owner": "self_employed_business",
    "self employed - professional": "self_employed_professional",
    "self employed professional": "self_employed_professional",
    "self-employed professional": "self_employed_professional",
    "self_employed professional": "self_employed_professional",
    "freelancer": "self_employed_professional",
    "contract": "contract",
    "contractor": "contract",
    "salaried_government": "salaried_government",
    "salaried_private": "salaried_private",
    "self_employed_business": "self_employed_business",
    "self_employed_professional": "self_employed_professional",
}


def _normalise_date(series: pd.Series) -> pd.Series:
    """Try multiple formats; return NaT for anything unparseable."""
    result = pd.to_datetime(series, dayfirst=True, errors="coerce")
    # Try with slashes / mixed separators
    mask = result.isna()
    if mask.any():
        attempt = pd.to_datetime(series[mask], format="%d/%m/%Y", errors="coerce")
        result[mask] = attempt
    mask = result.isna()
    if mask.any():
        attempt = pd.to_datetime(series[mask], format="%Y/%m/%d", errors="coerce")
        result[mask] = attempt
    return result


def _reject_reason(raw: pd.DataFrame) -> pd.Series:
    """Return the *first* rule that each row breaks (or '' if clean)."""
    reason = pd.Series("", index=raw.index)

    # 1. Missing required field
    missing_mask = raw[_REQUIRED_FIELDS].isnull().any(axis=1) | (
        raw[_REQUIRED_FIELDS].eq("").any(axis=1)
    )
    reason[missing_mask & (reason == "")] = "missing_required_field"

    # 2. Non-positive income
    income_bad = raw["monthly_income_inr"].astype(str).str.strip() != ""
    try:
        income_bad = pd.to_numeric(raw["monthly_income_inr"], errors="coerce") <= 0
    except Exception:
        pass
    reason[income_bad & (reason == "")] = "income_not_positive"

    # 3. Unparseable date
    dates = _normalise_date(raw["application_date"].astype(str))
    reason[dates.isna() & (reason == "")] = "unparseable_application_date"

    # 4. Credit score out of range
    scores = pd.to_numeric(raw["credit_score"], errors="coerce")
    credit_bad = scores.isna() | (scores < 300) | (scores > 900)
    reason[credit_bad & (reason == "")] = "credit_score_out_of_range"

    # 5. Duplicate application_id (keep first occurrence)
    dup_mask = raw.duplicated(subset=["application_id"], keep="first")
    reason[dup_mask & (reason == "")] = "duplicate_application_id"

    return reason


def clean(raw: pd.DataFrame, include_outcome_columns: bool = True) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Clean *raw* and return (cleaned_df, rejected_df)."""
    raw = raw.copy()

    reason = _reject_reason(raw)
    rejected_mask = reason != ""

    rejected = raw[rejected_mask].copy()
    rejected["rejection_reason"] = reason[rejected_mask]

    kept = raw[~rejected_mask].copy()

    # Normalise date to YYYY-MM-DD
    kept["application_date"] = (
        _normalise_date(kept["application_date"].astype(str))
        .dt.strftime("%Y-%m-%d")
    )

    # Strip city whitespace
    kept["applicant_city"] = kept["applicant_city"].str.strip()

    # Normalise employment type
    kept["employment_type"] = (
        kept["employment_type"].str.strip().str.lower()
        .map(lambda v: _EMPLOYMENT_CANONICAL.get(v, v))
    )

    # Cast integer columns
    kept["age_years"] = pd.to_numeric(kept["age_years"], errors="coerce").astype("Int64").astype(int)
    kept["tenure_months"] = pd.to_numeric(kept["tenure_months"], errors="coerce").astype("Int64").astype(int)

    return kept, rejected


def run(project_dir: Path | None = None) -> None:
    base = project_dir or PROJECT_DIR
    train_raw = pd.read_csv(base / "data" / "loan_applications_train.csv")
    predict_raw = pd.read_csv(base / "data" / "loan_applications_predict.csv")

    (base / "processed_data").mkdir(parents=True, exist_ok=True)
    (base / "output").mkdir(parents=True, exist_ok=True)

    cleaned, rejected = clean(train_raw, include_outcome_columns=True)
    cleaned.to_csv(base / "processed_data" / "loan_applications_cleaned.csv", index=False)
    rejected.to_csv(base / "output" / "rejected_records.csv", index=False)

    # Prediction file — no outcome columns, should be fully clean
    predict_cleaned, _ = clean(predict_raw, include_outcome_columns=False)
    predict_cleaned.to_csv(
        base / "processed_data" / "loan_applications_predict_cleaned.csv", index=False
    )
    print(f"Cleaned: {len(cleaned)} kept, {len(rejected)} rejected.")
    print(f"Prediction file: {len(predict_cleaned)} rows.")


if __name__ == "__main__":
    run()
