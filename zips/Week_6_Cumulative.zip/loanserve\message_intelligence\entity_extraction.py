"""loanserve/message_intelligence/entity_extraction.py — Week 6 Day 1"""
from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
import pandas as pd

from loanserve.data_access.database_loader import ApplicationDatabase

PROJECT_DIR = Path(__file__).resolve().parents[2]


def extract_references(text: str) -> list[str]:
    """Find LA000000 and LP000000 style references, return uppercase deduplicated sorted."""
    matches = re.findall(r"\bL[AP]\d{6}\b", text, flags=re.IGNORECASE)
    return sorted(list(set(m.upper() for m in matches)))


def extract_amounts(text: str) -> list[float]:
    """Find amounts preceded by Rs, Rs., or INR. Return as floats."""
    pattern = r"(?:Rs\.?|INR)\s*([\d,]+(?:\.\d+)?)"
    matches = re.findall(pattern, text, flags=re.IGNORECASE)
    amounts = []
    for m in matches:
        clean_num = m.replace(",", "")
        try:
            amounts.append(float(clean_num))
        except ValueError:
            pass
    return amounts


def extract_dates(text: str) -> list[str]:
    """Find DD/MM/YYYY or DD-MM-YY and return valid YYYY-MM-DD dates."""
    # Pattern looks for DD/MM/YYYY or DD-MM-YY
    pattern = r"\b(\d{2})[/-](\d{2})[/-](\d{2,4})\b"
    matches = re.findall(pattern, text)
    valid_dates = []
    for day_str, month_str, year_str in matches:
        year = int(year_str)
        if year < 100:
            year += 2000
        month = int(month_str)
        day = int(day_str)
        
        try:
            dt = datetime(year, month, day)
            valid_dates.append(dt.strftime("%Y-%m-%d"))
        except ValueError:
            # Invalid date like 32/01/2026 or 15/13/2026
            pass
            
    return valid_dates


def link_references(references: list[str], database: ApplicationDatabase) -> tuple[list[str], list[str]]:
    """Check which references exist in the database."""
    found = []
    not_found = []
    for ref in references:
        record = database.find_application(ref)
        if record is not None:
            found.append(ref)
        else:
            not_found.append(ref)
    return found, not_found


def run(project_dir: Path | None = None) -> None:
    base = project_dir or PROJECT_DIR
    (base / "output").mkdir(parents=True, exist_ok=True)
    
    raw = pd.read_csv(base / "data" / "customer_messages.csv")
    database = ApplicationDatabase(base / "database" / "loanserve.db")
    
    results = []
    for idx, row in raw.iterrows():
        msg_id = row["message_id"]
        text = str(row["message_text"])
        if not text.strip():
            continue
            
        refs = extract_references(text)
        amounts = extract_amounts(text)
        dates = extract_dates(text)
        
        if refs or amounts or dates:
            found, not_found = link_references(refs, database)
            results.append({
                "message_id": msg_id,
                "references_found": " ".join(found),
                "references_not_found": " ".join(not_found),
                "amounts": " ".join(str(a) for a in amounts),
                "dates": " ".join(dates)
            })
            
    out = pd.DataFrame(results)
    out_path = base / "output" / "message_entities.csv"
    out.to_csv(out_path, index=False)
    print(f"Written entities for {len(out)} messages to {out_path.name}")


if __name__ == "__main__":
    run()
