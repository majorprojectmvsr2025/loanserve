"""loanserve/retrieval/filtered_search.py — Week 7 Day 3"""
import re
from sentence_transformers import SentenceTransformer
import chromadb

def product_in_question(question: str) -> str:
    """Identify the product type named in the question."""
    q = question.lower()
    
    if "home" in q:
        return "home"
    if "vehicle" in q or "two-wheeler" in q or "car" in q:
        return "vehicle"
    if "gold" in q:
        return "gold"
    if "personal" in q:
        return "personal"
        
    return "all"


def policy_filter(product_type: str) -> dict:
    """Return a ChromaDB where-filter for the given product type."""
    if product_type == "all":
        return {"product_type": "all"}
        
    return {
        "product_type": {
            "$in": [product_type, "all"]
        }
    }


def filtered_search(collection: chromadb.Collection, question: str, embedder: SentenceTransformer, how_many: int = 3) -> list[dict]:
    """Search policy chunks using metadata filtering by product type."""
    product_type = product_in_question(question)
    where_filter = policy_filter(product_type)
    
    question_vector = embedder.encode(question, normalize_embeddings=True).tolist()
    
    results = collection.query(
        query_embeddings=[question_vector],
        n_results=how_many,
        include=["metadatas", "documents", "distances"],
        where=where_filter
    )
    
    found = []
    if results["ids"] and results["ids"][0]:
        for idx in range(len(results["ids"][0])):
            found.append({
                "chunk_id": results["ids"][0][idx],
                "text": results["documents"][0][idx],
                "heading": results["metadatas"][0][idx]["heading"],
                "document_id": results["metadatas"][0][idx]["document_id"],
                "distance": results["distances"][0][idx]
            })
            
    return found
