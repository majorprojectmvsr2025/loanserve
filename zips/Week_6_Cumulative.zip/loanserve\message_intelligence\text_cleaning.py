"""loanserve/message_intelligence/text_cleaning.py — Week 5 Day 1"""
import re
from pathlib import Path
import pandas as pd

PROJECT_DIR = Path(__file__).resolve().parents[2]

def mask_ticket_references(text: str) -> str:
    """Replace TKT-12345 or CASE-12345 with <ticket_ref>."""
    return re.sub(r"(?:TKT|CASE)-\d+", "<ticket_ref>", text)

def strip_quoted_reply(text: str) -> str:
    """Strip quoted replies starting with 'On <date>... wrote:'."""
    # Look for \nOn ... wrote:\n> or similar
    pattern = r"\nOn .*? wrote:\n>.*$"
    res = re.sub(pattern, "", text, flags=re.DOTALL | re.IGNORECASE)
    # Also just \nOn ... wrote:\n
    pattern2 = r"\nOn .*? wrote:\n.*$"
    res = re.sub(pattern2, "", res, flags=re.DOTALL | re.IGNORECASE)
    return res

def strip_signature(text: str) -> str:
    """Strip everything from \n--\n onwards."""
    return text.split("\n--\n")[0]

def mask_urls(text: str) -> str:
    """Replace http/https/www links with <url>."""
    text = re.sub(r"https?://\S+", "<url>", text)
    text = re.sub(r"www\.\S+", "<url>", text)
    return text

def mask_application_references(text: str) -> str:
    """Replace LA000123 or LP004450 with <application_ref>."""
    return re.sub(r"L[AP]\d{6}", "<application_ref>", text)

def strip_greeting(text: str) -> str:
    """Remove common greetings from the beginning of the text."""
    pattern = r"^(?:Dear\s+(?:sir|madam)|Hi\s+team|Good\s+morning|Hello)[,\s]*"
    return re.sub(pattern, "", text, flags=re.IGNORECASE)

def strip_sign_off(text: str) -> str:
    """Remove common sign-offs from the end of the text."""
    pattern = r"(?:\s+Thanks in advance\.|\s+Awaitng your response\.|\s+Regards\.)\s*$"
    return re.sub(pattern, "", text, flags=re.IGNORECASE)

def clean_message(text: str) -> str:
    if pd.isna(text) or not str(text).strip():
        return ""
    text = str(text)
    # Clean order: signature, quoted reply, sign-off, greeting, masks
    text = strip_signature(text)
    text = strip_quoted_reply(text)
    text = strip_sign_off(text)
    text = strip_greeting(text)
    text = mask_urls(text)
    text = mask_application_references(text)
    text = mask_ticket_references(text)
    return text.strip()

def run(project_dir: Path | None = None) -> None:
    base = project_dir or PROJECT_DIR
    (base / "processed_data").mkdir(parents=True, exist_ok=True)
    
    raw = pd.read_csv(base / "data" / "customer_messages.csv")
    cleaned_text = [clean_message(t) for t in raw["message_text"]]
    
    out = raw.copy()
    out["cleaned_text"] = cleaned_text
    
    out_path = base / "processed_data" / "messages_cleaned.csv"
    out.to_csv(out_path, index=False)
    print(f"Written cleaned messages to {out_path.name}")

if __name__ == "__main__":
    run()
