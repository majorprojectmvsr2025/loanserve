"""loanserve/risk_models/tree_models.py — Week 4 Day 1

Decision tree and random forest on the shared preparation pipeline.
Run as module: python -m loanserve.risk_models.tree_models
"""
from __future__ import annotations

import json
from pathlib import Path

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.tree import DecisionTreeClassifier

from config import constants
from loanserve.risk_models.feature_pipeline import (
    build_feature_pipeline,
    split_for_modelling,
)

PROJECT_DIR = Path(__file__).resolve().parents[2]


def build_decision_tree(X_train, y_train) -> Pipeline:
    prep = build_feature_pipeline()
    estimator = DecisionTreeClassifier(
        max_depth=8,
        class_weight="balanced",
        random_state=constants.RANDOM_SEED,
    )
    model = Pipeline(steps=prep.steps + [("model", estimator)])
    model.fit(X_train, y_train)
    return model


def build_random_forest(X_train, y_train) -> Pipeline:
    prep = build_feature_pipeline()
    estimator = RandomForestClassifier(
        n_estimators=200,
        max_depth=10,
        class_weight="balanced",
        random_state=constants.RANDOM_SEED,
        n_jobs=-1,
    )
    model = Pipeline(steps=prep.steps + [("model", estimator)])
    model.fit(X_train, y_train)
    return model


def feature_importances(model: Pipeline) -> "pd.DataFrame":
    """Return a DataFrame with columns 'feature' and 'importance', sorted descending."""
    names = list(model.steps[0][1].get_feature_names_out())
    importances = list(model.named_steps["model"].feature_importances_)
    result = pd.DataFrame({"feature": names, "importance": importances})
    return result.sort_values("importance", ascending=False).reset_index(drop=True)


def run(project_dir: Path | None = None) -> None:
    base = project_dir or PROJECT_DIR
    (base / "artifacts").mkdir(parents=True, exist_ok=True)
    (base / "output").mkdir(parents=True, exist_ok=True)

    cleaned_path = base / "processed_data" / "loan_applications_cleaned.csv"
    X_train, X_holdout, y_train, y_holdout = split_for_modelling(cleaned_path)

    dt = build_decision_tree(X_train, y_train)
    rf = build_random_forest(X_train, y_train)

    joblib.dump(dt, base / "artifacts" / "decision_tree.pkl")
    joblib.dump(rf, base / "artifacts" / "random_forest.pkl")

    # Class-weight comparison JSON — balanced vs. none
    from sklearn.metrics import recall_score, roc_auc_score
    prep = build_feature_pipeline()
    unweighted_estimator = RandomForestClassifier(
        n_estimators=200,
        max_depth=10,
        class_weight=None,
        random_state=constants.RANDOM_SEED,
        n_jobs=-1,
    )
    unweighted_rf = Pipeline(steps=prep.steps + [("model", unweighted_estimator)])
    unweighted_rf.fit(X_train, y_train)

    comparison = {
        "balanced": {
            "roc_auc": round(roc_auc_score(
                y_holdout, rf.predict_proba(X_holdout)[:, 1]), 4),
            "defaulters_caught": round(float(recall_score(
                y_holdout, rf.predict(X_holdout))), 4),
        },
        "none": {
            "roc_auc": round(roc_auc_score(
                y_holdout, unweighted_rf.predict_proba(X_holdout)[:, 1]), 4),
            "defaulters_caught": round(float(recall_score(
                y_holdout, unweighted_rf.predict(X_holdout))), 4),
        },
    }
    with open(base / "output" / "class_weight_comparison.json", "w") as fh:
        json.dump(comparison, fh, indent=2)
    print("Tree models saved.")


if __name__ == "__main__":
    run()
