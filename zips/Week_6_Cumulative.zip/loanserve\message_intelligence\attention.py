"""loanserve/message_intelligence/attention.py — Week 5 Day 3"""
import numpy as np


def stable_softmax(scores: np.ndarray) -> np.ndarray:
    """Return softmax probabilities along the last axis, stable against overflow."""
    # Subtract max for numerical stability
    shifted = scores - np.max(scores, axis=-1, keepdims=True)
    exp_scores = np.exp(shifted)
    return exp_scores / np.sum(exp_scores, axis=-1, keepdims=True)


def attention_scores(queries: np.ndarray, keys: np.ndarray) -> np.ndarray:
    """Return scaled dot-product attention scores.
    
    queries: (N, d)
    keys: (M, d)
    returns: (N, M)
    """
    d_k = queries.shape[-1]
    return (queries @ keys.T) / np.sqrt(d_k)


def scaled_dot_product_attention(queries: np.ndarray, keys: np.ndarray, values: np.ndarray, allowed: np.ndarray = None) -> tuple[np.ndarray, np.ndarray]:
    """Return (attended_vectors, weights).
    
    If allowed is provided (boolean array of shape (N, M)), positions where it is False 
    receive zero attention.
    """
    scores = attention_scores(queries, keys)
    if allowed is not None:
        scores = np.where(allowed, scores, -np.inf)
    
    weights = stable_softmax(scores)
    
    # In case a row is completely disallowed, the softmax might output NaNs (0/0)
    # We should replace NaNs with 0 if necessary, but according to the tests, 
    # we just need to ensure the weights are correct for unmasked positions
    weights = np.nan_to_num(weights, nan=0.0)
    
    # If an entire row is masked, all weights are 0, so attended vector is 0
    # But wait, test says "What is left still adds to one: the attention the masked 
    # positions cannot have is shared out among the rest." This works naturally with -inf.
    
    attended = weights @ values
    return attended, weights
