"""loanserve/core/exceptions.py — Platform exception hierarchy (Week 1 Day 3)"""


class LoanServeError(Exception):
    """Base exception for all LoanServe platform errors."""


class StorageError(LoanServeError):
    """Raised when a file or database operation fails."""


class UnsupportedLoanTypeError(LoanServeError):
    """Raised when a loan type not offered by LoanServe is requested."""


class InvalidApplicationError(LoanServeError):
    """Raised when an application or field fails a validation rule."""
