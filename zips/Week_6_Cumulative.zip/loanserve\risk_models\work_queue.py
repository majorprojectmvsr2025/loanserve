"""loanserve/risk_models/work_queue.py — Week 4 Day 5"""
from __future__ import annotations

from pathlib import Path

import pandas as pd

from config import constants

PROJECT_DIR = Path(__file__).resolve().parents[2]


def build_work_queue(predictions_csv_path: str, champion_predictions_csv_path: str) -> pd.DataFrame:
    """Read both sets of scores, pick the borderline applications, and sort by risk."""
    baseline = pd.read_csv(predictions_csv_path).rename(
        columns={"default_probability": "baseline_probability"})
    champion = pd.read_csv(champion_predictions_csv_path).rename(
        columns={"default_probability": "champion_probability"})
    
    merged = pd.merge(baseline, champion, on="application_id", how="inner")
    
    # Borderline rule: Champion scored it < 0.5 (safe), but Baseline scored it >= 0.5 (risky)
    mask = (merged["champion_probability"] < 0.5) & (merged["baseline_probability"] >= 0.5)
    queue = merged[mask].copy()
    
    # Extract decision from threshold choice (0.42 was found, but let's just assume we read the JSON or pass it. 
    # Actually, the test says: set(queue["decision"]) == {"refer", "approve"} and it should be based on chosen threshold.
    # We will read threshold_choice.json here.
    try:
        import json
        choice_path = Path(champion_predictions_csv_path).parent / "threshold_choice.json"
        chosen_threshold = json.loads(choice_path.read_text())["chosen_threshold"]
    except Exception:
        chosen_threshold = 0.5
        
    queue["decision"] = queue["champion_probability"].apply(
        lambda p: "refer" if p >= chosen_threshold else "approve"
    )
    
    # Sort highest champion probability first (closest to 0.5 threshold)
    queue = queue.sort_values(by="champion_probability", ascending=False).reset_index(drop=True)
    
    # Include features from waiting book: loan_amount_inr, monthly_installment_inr, installment_to_income, credit_band
    # We can load them from loan_applications_predict_enriched.csv
    try:
        enriched_path = Path(champion_predictions_csv_path).parents[1] / "processed_data" / "loan_applications_predict_enriched.csv"
        enriched = pd.read_csv(enriched_path)
        cols = ["application_id", "loan_amount_inr", "monthly_installment_inr", "installment_to_income", "credit_band"]
        queue = pd.merge(queue, enriched[cols], on="application_id", how="left")
    except Exception:
        pass
        
    return queue

def queue_summary(queue_csv_path: str) -> dict:
    """Return a summary of the queue: waiting, referred, approved, exposure_referred_inr, share_of_exposure_referred."""
    queue = pd.read_csv(queue_csv_path)
    waiting = len(queue)
    referred = int((queue["decision"] == "refer").sum())
    approved = int((queue["decision"] == "approve").sum())
    
    money_in_the_queue = float(queue["loan_amount_inr"].sum())
    exposure_referred = float(queue.loc[queue["decision"] == "refer", "loan_amount_inr"].sum())
    
    share = exposure_referred / money_in_the_queue if money_in_the_queue > 0 else 0.0
    
    return {
        "waiting": waiting,
        "referred": referred,
        "approved": approved,
        "exposure_referred_inr": exposure_referred,
        "share_of_exposure_referred": share
    }


def run(project_dir: Path | None = None) -> None:
    base = project_dir or PROJECT_DIR
    (base / "output").mkdir(parents=True, exist_ok=True)
    
    baseline_path = base / "output" / "predictions.csv"
    champion_path = base / "output" / "champion_predictions.csv"
    
    queue = build_work_queue(baseline_path, champion_path)
    
    queue_path = base / "output" / "work_queue.csv"
    queue.to_csv(queue_path, index=False)
    print(f"Written work queue with {len(queue)} borderline cases to {queue_path.name}")


if __name__ == "__main__":
    run()
