python -m loanserve.message_intelligence.message_classifier
python -m loanserve.message_intelligence.thread_summary
python -m loanserve.message_intelligence.entity_extraction
python -m loanserve.message_intelligence.batch_pipeline
python -m loanserve.message_intelligence.injection_guard
python -m loanserve.message_intelligence.escalation
python -m loanserve.retrieval.vector_store
