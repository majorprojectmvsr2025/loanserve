"""loanserve/api/repository.py — Week 2 Day 4 & Week 3 Day 1

In-memory and SQL-backed repositories that both implement the same interface.
"""
import uuid
from abc import ABC, abstractmethod
from contextlib import contextmanager
from typing import Dict, List, Optional, Tuple

from loanserve.api.orm_models import Applicant, StoredApplication


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------

class ApplicationRepository(ABC):
    """Storage interface that the HTTP layer depends on."""

    @abstractmethod
    def save_application(self, record: dict) -> dict:
        """Store *record* and return a dict that includes ``application_id``."""

    @abstractmethod
    def find_application(self, application_id: str) -> Optional[dict]:
        """Return the stored record or ``None``."""

    @abstractmethod
    def replace_application(self, application_id: str, record: dict) -> Optional[dict]:
        """Replace the stored record; return the new dict or ``None`` if not found."""

    @abstractmethod
    def delete_application(self, application_id: str) -> bool:
        """Delete the record; return ``True`` if it existed."""

    @abstractmethod
    def list_applications(
        self, loan_type: Optional[str], limit: int, offset: int
    ) -> Tuple[List[dict], int]:
        """Return (page, total_count).  *loan_type* filters when provided."""

    @abstractmethod
    def count_applications(self) -> int:
        """Return the total number of stored applications."""


# ---------------------------------------------------------------------------
# ID generation
# ---------------------------------------------------------------------------

def _new_id() -> str:
    """Return a UUID-based identifier that never reuses."""
    return f"LA{uuid.uuid4().hex[:6].upper()}"


# ---------------------------------------------------------------------------
# In-memory repository (Week 2 Day 4)
# ---------------------------------------------------------------------------

class InMemoryApplicationRepository(ApplicationRepository):

    def __init__(self):
        self._store: Dict[str, dict] = {}
        self._counter: int = 0

    def _next_id(self) -> str:
        self._counter += 1
        return f"LA{self._counter:06d}"

    def save_application(self, record: dict) -> dict:
        application_id = self._next_id()
        stored = dict(record, application_id=application_id)
        self._store[application_id] = stored
        return stored

    def find_application(self, application_id: str) -> Optional[dict]:
        return self._store.get(application_id)

    def replace_application(self, application_id: str, record: dict) -> Optional[dict]:
        if application_id not in self._store:
            return None
        updated = dict(record, application_id=application_id)
        self._store[application_id] = updated
        return updated

    def delete_application(self, application_id: str) -> bool:
        if application_id not in self._store:
            return False
        del self._store[application_id]
        return True

    def list_applications(
        self, loan_type: Optional[str], limit: int, offset: int
    ) -> Tuple[List[dict], int]:
        all_records = list(self._store.values())
        if loan_type is not None:
            all_records = [r for r in all_records if r.get("loan_type") == loan_type]
        total = len(all_records)
        return all_records[offset: offset + limit], total

    def count_applications(self) -> int:
        return len(self._store)


# ---------------------------------------------------------------------------
# SQL-backed repository (Week 3 Day 1)
# ---------------------------------------------------------------------------

def _row_to_dict(row: StoredApplication) -> dict:
    return {
        "application_id": row.application_id,
        "applicant_name": row.applicant.applicant_name,
        "loan_type": row.loan_type,
        "pan_number": row.pan_number,
        "mobile_number": row.mobile_number,
        "email_address": row.email_address,
        "loan_amount_inr": row.loan_amount_inr,
        "tenure_months": row.tenure_months,
        "monthly_income_inr": row.monthly_income_inr,
        "age_years": row.age_years,
        "credit_score": row.credit_score,
        "collateral_value_inr": row.collateral_value_inr,
    }


class SqlApplicationRepository(ApplicationRepository):

    def __init__(self, session_factory):
        self._session_factory = session_factory
        self._counter: int = 0

    def _next_id(self, session) -> str:
        """Generate next sequential application ID using DB count."""
        count = session.query(StoredApplication).count()
        return f"LA{count + 1:06d}"

    def save_application(self, record: dict) -> dict:
        with self._session_factory() as session:
            application_id = f"LA{session.query(StoredApplication).count() + 1:06d}"
            applicant_name = record.get("applicant_name", "Unknown")
            # Get or create applicant
            applicant = session.get(Applicant, applicant_name)
            if applicant is None:
                applicant = Applicant(applicant_name=applicant_name, applications=[])
                session.add(applicant)
            row = StoredApplication(
                application_id=application_id,
                applicant_name=applicant_name,
                loan_type=record.get("loan_type", ""),
                pan_number=record.get("pan_number", ""),
                mobile_number=record.get("mobile_number", ""),
                email_address=record.get("email_address", ""),
                loan_amount_inr=float(record.get("loan_amount_inr", 0)),
                tenure_months=int(record.get("tenure_months", 0)),
                monthly_income_inr=float(record.get("monthly_income_inr", 0)),
                age_years=int(record.get("age_years", 0)),
                credit_score=int(record.get("credit_score", 0)),
                collateral_value_inr=float(record.get("collateral_value_inr", 0)),
            )
            applicant.applications.append(row)
            session.commit()
            return _row_to_dict(row)

    def find_application(self, application_id: str) -> Optional[dict]:
        with self._session_factory() as session:
            row = session.get(StoredApplication, application_id)
            return _row_to_dict(row) if row is not None else None

    def replace_application(self, application_id: str, record: dict) -> Optional[dict]:
        with self._session_factory() as session:
            row = session.get(StoredApplication, application_id)
            if row is None:
                return None
            row.loan_type = record.get("loan_type", row.loan_type)
            row.loan_amount_inr = float(record.get("loan_amount_inr", row.loan_amount_inr))
            row.tenure_months = int(record.get("tenure_months", row.tenure_months))
            row.monthly_income_inr = float(
                record.get("monthly_income_inr", row.monthly_income_inr))
            row.age_years = int(record.get("age_years", row.age_years))
            row.credit_score = int(record.get("credit_score", row.credit_score))
            row.collateral_value_inr = float(
                record.get("collateral_value_inr", row.collateral_value_inr))
            session.commit()
            return _row_to_dict(row)

    def delete_application(self, application_id: str) -> bool:
        with self._session_factory() as session:
            row = session.get(StoredApplication, application_id)
            if row is None:
                return False
            session.delete(row)
            session.commit()
            return True

    def list_applications(
        self, loan_type: Optional[str], limit: int, offset: int
    ) -> Tuple[List[dict], int]:
        with self._session_factory() as session:
            query = session.query(StoredApplication)
            if loan_type is not None:
                query = query.filter(StoredApplication.loan_type == loan_type)
            total = query.count()
            rows = query.offset(offset).limit(limit).all()
            return [_row_to_dict(r) for r in rows], total

    def count_applications(self) -> int:
        with self._session_factory() as session:
            return session.query(StoredApplication).count()
