"""loanserve/risk_models/baseline_model.py — Week 3 Day 5

Logistic regression baseline.
Run as module: python -m loanserve.risk_models.baseline_model
"""
from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

from config import constants
from loanserve.risk_models.feature_pipeline import (
    build_feature_pipeline,
    select_modelling_columns,
    split_for_modelling,
)

PROJECT_DIR = Path(__file__).resolve().parents[2]


def build_baseline_model() -> Pipeline:
    """Return a fitted logistic-regression pipeline."""
    cleaned_path = PROJECT_DIR / "processed_data" / "loan_applications_cleaned.csv"
    X_train, _, y_train, _ = split_for_modelling(cleaned_path)
    pipeline = build_feature_pipeline()
    estimator = LogisticRegression(
        max_iter=1000,
        class_weight="balanced",
        random_state=constants.RANDOM_SEED,
    )
    full_pipeline = Pipeline(steps=pipeline.steps + [("model", estimator)])
    full_pipeline.fit(X_train, y_train)
    return full_pipeline


def load_model(model_path) -> Pipeline:
    """Load and return a saved pipeline."""
    return joblib.load(model_path)


def predict_default_probability(model: Pipeline, df: pd.DataFrame) -> np.ndarray:
    """Return an array of default probabilities for each row in *df*."""
    X = select_modelling_columns(df)
    return model.predict_proba(X)[:, 1]


def run(project_dir: Path | None = None) -> None:
    base = project_dir or PROJECT_DIR
    (base / "artifacts").mkdir(parents=True, exist_ok=True)
    (base / "output").mkdir(parents=True, exist_ok=True)

    model = build_baseline_model()
    model_path = base / "artifacts" / "baseline_model.pkl"
    joblib.dump(model, model_path)
    print(f"Saved {model_path}")

    # Score the prediction set
    predict_cleaned = pd.read_csv(
        base / "processed_data" / "loan_applications_predict_cleaned.csv"
    )
    scores = predict_default_probability(model, predict_cleaned)
    out = predict_cleaned[["application_id"]].copy()
    out["default_probability"] = scores
    out.to_csv(base / "output" / "predictions.csv", index=False)
    print(f"Scored {len(out)} applications.")


if __name__ == "__main__":
    run()
