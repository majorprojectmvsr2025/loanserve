"""loanserve/assistant/agents.py — Week 8 Day 1 and 2"""
from __future__ import annotations
from loanserve.assistant.state import AssistantState

PLANNER_KEYS = ["tool", "arguments", "why"]
RESOLVER_KEYS = ["draft", "needs_approval"]
RESPONDER_KEYS = ["answer", "confidence"]

PLANNER_PROMPT = """
You are the planner for the LoanServe assistant.
The customer asked: {question}

Triage found:
- category: {category}
- urgency: {urgency}

Choose a tool to call.
Available tools:
- calculate_installment
- lookup_application
- predict_default_risk
- search_policy_documents

Your response must be JSON containing EXACTLY:
- "tool": the name of the tool to call.
- "arguments": a JSON object of arguments for the tool.
- "why": a brief string explaining why you chose this tool.
"""

RESOLVER_PROMPT = """
You are the resolver for the LoanServe assistant.
Draft an answer.
Your response must be JSON containing EXACTLY:
- "draft": the drafted answer.
- "needs_approval": a boolean indicating if this draft requires manager approval.
"""

RESPONDER_PROMPT = """
You are the responder for the LoanServe assistant.
Rewrite the drafted answer to be polite and professional, changing no figure.
You must also assess your confidence in the drafted answer.
Your response must be JSON containing EXACTLY:
- "answer": the rewritten answer, with no figure changed.
- "confidence": a float between 0.0 and 1.0 indicating confidence.
"""

def plan_tools(state: AssistantState) -> dict:
    pass

def write_response(state: AssistantState) -> dict:
    pass
