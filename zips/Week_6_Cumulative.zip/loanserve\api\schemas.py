"""loanserve/api/schemas.py — Week 2 Day 3-4, Week 3

Pydantic request/response models for the FastAPI service.
"""
from typing import List, Optional

from pydantic import BaseModel, field_validator, model_validator

from config import constants
from loanserve.core.validators import (
    validate_email_address,
    validate_mobile_number,
    validate_pan_number,
)


# ---------------------------------------------------------------------------
# Request model (submitted by the caller)
# ---------------------------------------------------------------------------

class LoanApplicationRequest(BaseModel):
    pan_number: str
    mobile_number: str
    email_address: str
    applicant_name: str
    loan_type: str
    loan_amount_inr: float
    tenure_months: int
    monthly_income_inr: float
    age_years: int
    credit_score: int
    collateral_value_inr: float = 0.0

    @field_validator("pan_number")
    @classmethod
    def _validate_pan(cls, v: str) -> str:
        return validate_pan_number(v)

    @field_validator("mobile_number")
    @classmethod
    def _validate_mobile(cls, v: str) -> str:
        return validate_mobile_number(v)

    @field_validator("email_address")
    @classmethod
    def _validate_email(cls, v: str) -> str:
        return validate_email_address(v)

    @field_validator("loan_type")
    @classmethod
    def _validate_loan_type(cls, v: str) -> str:
        if v.lower() not in constants.LOAN_PRODUCTS:
            raise ValueError(
                f"'{v}' is not a loan type offered by LoanServe. "
                f"Offered: {sorted(constants.LOAN_PRODUCTS)}"
            )
        return v.lower()

    @field_validator("loan_amount_inr")
    @classmethod
    def _validate_amount(cls, v: float) -> float:
        if v <= 0:
            raise ValueError("loan_amount_inr must be positive.")
        return v

    @field_validator("credit_score")
    @classmethod
    def _validate_credit_score(cls, v: int) -> int:
        if not (constants.MINIMUM_CREDIT_SCORE_FOR_BUREAU
                <= v
                <= constants.MAXIMUM_CREDIT_SCORE_FOR_BUREAU):
            raise ValueError(
                f"credit_score {v} is outside the bureau range "
                f"{constants.MINIMUM_CREDIT_SCORE_FOR_BUREAU}–"
                f"{constants.MAXIMUM_CREDIT_SCORE_FOR_BUREAU}."
            )
        return v

    @field_validator("tenure_months")
    @classmethod
    def _validate_tenure(cls, v: int) -> int:
        max_tenure = max(p["max_tenure"] for p in constants.LOAN_PRODUCTS.values())
        if v <= 0 or v > max_tenure:
            raise ValueError(
                f"tenure_months {v} is outside the permitted range 1–{max_tenure}."
            )
        return v

    @model_validator(mode="after")
    def _require_collateral_for_secured(self) -> "LoanApplicationRequest":
        if self.loan_type in constants.SECURED_LOAN_TYPES and self.collateral_value_inr <= 0:
            raise ValueError(
                f"A {self.loan_type} loan is secured — collateral_value_inr is required "
                "and must be positive."
            )
        return self


# ---------------------------------------------------------------------------
# Response model (returned to the caller)
# ---------------------------------------------------------------------------

class LoanApplicationResponse(BaseModel):
    application_id: str
    applicant_name: str
    loan_type: str
    loan_amount_inr: float
    tenure_months: int
    interest_rate_percent: float
    monthly_installment_inr: float
    is_eligible: bool
    rejection_reasons: List[str] = []
