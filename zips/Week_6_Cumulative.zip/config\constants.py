# config/constants.py — all platform-wide configuration values

# ----------------------------------------------------------------------------
# Loan product catalogue
# ----------------------------------------------------------------------------

LOAN_PRODUCTS = {
    "home":     {"rate": 8.50,  "max_amount": 15_000_000, "max_tenure": 300, "secured": True},
    "vehicle":  {"rate": 9.75,  "max_amount":  2_000_000, "max_tenure":  84, "secured": True},
    "gold":     {"rate": 11.00, "max_amount":  1_500_000, "max_tenure":  36, "secured": True},
    "personal": {"rate": 14.50, "max_amount":  1_500_000, "max_tenure":  60, "secured": False},
}

SECURED_LOAN_TYPES = [product for product, cfg in LOAN_PRODUCTS.items() if cfg["secured"]]
UNSECURED_LOAN_TYPES = [product for product, cfg in LOAN_PRODUCTS.items() if not cfg["secured"]]

# Eligibility thresholds
MINIMUM_AGE_YEARS = 21
MAXIMUM_AGE_YEARS = 60
MAXIMUM_DEBT_TO_INCOME_RATIO = 0.50
MINIMUM_CREDIT_SCORE = 650
MAXIMUM_LOAN_TO_VALUE_RATIO = 0.80
MINIMUM_CREDIT_SCORE_FOR_BUREAU = 300
MAXIMUM_CREDIT_SCORE_FOR_BUREAU = 900

# ----------------------------------------------------------------------------
# CORS
# ----------------------------------------------------------------------------

ALLOWED_ORIGINS = [
    "https://loanserve.example",
    "https://admin.loanserve.example",
    "http://localhost:3000",
    "http://localhost:5173",
]

# ----------------------------------------------------------------------------
# Data / modelling columns
# ----------------------------------------------------------------------------

MODELLING_COLUMNS = (
    "loan_type",
    "loan_amount_inr",
    "tenure_months",
    "monthly_income_inr",
    "age_years",
    "credit_score",
    "employment_type",
    "applicant_city",
)

NUMERIC_MODELLING_COLUMNS = (
    "loan_amount_inr",
    "tenure_months",
    "monthly_income_inr",
    "age_years",
    "credit_score",
)

CATEGORICAL_MODELLING_COLUMNS = (
    "loan_type",
    "employment_type",
)

TARGET_COLUMN = "defaulted"
RANDOM_SEED = 42
CROSS_VALIDATION_FOLDS = 5

# Engineered columns added in Week 4 Day 3
ENGINEERED_NUMERIC_COLUMNS = (
    "monthly_installment_inr",
    "installment_to_income",
)

ENGINEERED_CATEGORICAL_COLUMNS = (
    "credit_band",
)

# Credit banding — ordered from worst to best
CREDIT_BAND_CUTS = [0, 579, 669, 739, 799, 900]
CREDIT_BAND_NAMES = ["poor", "fair", "good", "very_good", "exceptional"]

# ----------------------------------------------------------------------------
# Cost model for threshold selection
# ----------------------------------------------------------------------------

COST_OF_A_MISSED_DEFAULT_INR = 500_000
COST_OF_A_REFUSED_GOOD_APPLICANT_INR = 25_000

# ----------------------------------------------------------------------------
# Retrieval / RAG
# ----------------------------------------------------------------------------

POLICY_CHUNK_CHARACTERS = 800
EMBEDDING_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

# ----------------------------------------------------------------------------
# LLM
# ----------------------------------------------------------------------------

LLM_REQUIRED_KEYS = ["intent", "key_facts", "sentiment", "suggested_action"]
