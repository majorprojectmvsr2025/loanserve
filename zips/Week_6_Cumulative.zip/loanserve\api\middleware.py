"""loanserve/api/middleware.py — Week 3 Day 2

Sliding-window rate limiter and request-logging middleware.
"""
import os
import time
from collections import deque
from pathlib import Path
from typing import Dict, Optional

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware


# ---------------------------------------------------------------------------
# Sliding window rate limiter
# ---------------------------------------------------------------------------

class SlidingWindowRateLimiter:
    """Allow at most *max_requests* requests per *window_seconds* per caller."""

    def __init__(self, max_requests: int, window_seconds: float):
        self._max = max_requests
        self._window = window_seconds
        self._timestamps: Dict[str, deque] = {}

    def is_allowed(self, caller_id: str, now: float) -> bool:
        if caller_id not in self._timestamps:
            self._timestamps[caller_id] = deque()
        window = self._timestamps[caller_id]
        cutoff = now - self._window
        while window and window[0] <= cutoff:
            window.popleft()
        if len(window) >= self._max:
            return False
        window.append(now)
        return True


# ---------------------------------------------------------------------------
# Request-logging middleware
# ---------------------------------------------------------------------------

class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Log every request as ``METHOD PATH STATUS  <duration>ms``."""

    def __init__(self, app, log_path: str):
        super().__init__(app)
        self._log_path = Path(log_path)
        self._log_path.parent.mkdir(parents=True, exist_ok=True)

    async def dispatch(self, request: Request, call_next):
        start = time.perf_counter()
        response = await call_next(request)
        duration_ms = (time.perf_counter() - start) * 1000
        line = (
            f"{request.method} {request.url.path} {response.status_code}  "
            f"{duration_ms:.1f}ms\n"
        )
        with open(self._log_path, "a", encoding="utf-8") as fh:
            fh.write(line)
        return response


# ---------------------------------------------------------------------------
# Rate-limiting middleware
# ---------------------------------------------------------------------------

class RateLimitingMiddleware(BaseHTTPMiddleware):
    """Enforce *max_requests_per_minute* per client IP using a sliding window."""

    def __init__(self, app, max_requests_per_minute: int):
        super().__init__(app)
        self._limiter = SlidingWindowRateLimiter(max_requests_per_minute, 60.0)

    async def dispatch(self, request: Request, call_next):
        caller_id = request.client.host if request.client else "unknown"
        if not self._limiter.is_allowed(caller_id, time.time()):
            from starlette.responses import JSONResponse
            return JSONResponse(
                status_code=429,
                content={"detail": "Too many requests. Please slow down."},
            )
        return await call_next(request)
