"""loanserve/core/decorators.py — Week 1 Day 5"""
import functools
import time


def measure_duration(func):
    """Wrap *func* so that its last wall-clock execution time is stored on it."""

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        wrapper.last_duration_seconds = time.perf_counter() - start
        return result

    wrapper.last_duration_seconds = 0.0
    return wrapper
