"""loanserve/risk_models/champion_model.py — Week 4 Day 4"""
from __future__ import annotations

from pathlib import Path

import joblib
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import RandomizedSearchCV
from scipy.stats import randint

from config import constants
from loanserve.risk_models.feature_pipeline import split_for_modelling
from loanserve.risk_models.tree_models import feature_importances

PROJECT_DIR = Path(__file__).resolve().parents[2]


def build_enriched_feature_pipeline() -> Pipeline:
    numeric_cols = list(constants.NUMERIC_MODELLING_COLUMNS) + list(constants.ENGINEERED_NUMERIC_COLUMNS)
    categorical_cols = list(constants.CATEGORICAL_MODELLING_COLUMNS) + list(constants.ENGINEERED_CATEGORICAL_COLUMNS)
    
    numeric_transformer = Pipeline(steps=[
        ("impute", SimpleImputer(strategy="median")),
        ("scale", StandardScaler()),
    ])
    categorical_transformer = Pipeline(steps=[
        ("impute", SimpleImputer(strategy="constant", fill_value="missing")),
        ("encode", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ])
    preprocessor = ColumnTransformer(transformers=[
        ("num", numeric_transformer, numeric_cols),
        ("cat", categorical_transformer, categorical_cols),
    ])
    return Pipeline(steps=[("preprocessor", preprocessor)])


def tune_champion(X_train, y_train) -> Pipeline:
    prep = build_enriched_feature_pipeline()
    rf = RandomForestClassifier(
        class_weight="balanced", 
        random_state=constants.RANDOM_SEED, 
        n_jobs=-1
    )
    model = Pipeline(steps=prep.steps + [("model", rf)])
    
    param_dist = {
        "model__n_estimators": randint(100, 300),
        "model__max_depth": randint(8, 15),
    }
    
    search = RandomizedSearchCV(
        model, 
        param_distributions=param_dist, 
        n_iter=10, 
        cv=3, 
        scoring="roc_auc", 
        random_state=constants.RANDOM_SEED,
        n_jobs=-1
    )
    search.fit(X_train, y_train)
    return search.best_estimator_


def run(project_dir: Path | None = None) -> None:
    base = project_dir or PROJECT_DIR
    (base / "artifacts").mkdir(parents=True, exist_ok=True)
    (base / "output").mkdir(parents=True, exist_ok=True)
    
    enriched_path = base / "processed_data" / "loan_applications_enriched.csv"
    X_train, X_holdout, y_train, y_holdout = split_for_modelling(enriched_path)
    
    # 1. Train and save champion
    print("Tuning champion model...")
    champion = tune_champion(X_train, y_train)
    
    champion_path = base / "artifacts" / "champion.pkl"
    joblib.dump(champion, champion_path)
    print(f"Saved champion to {champion_path}")
    
    # 2. Write champion predictions
    predict_enriched = pd.read_csv(
        base / "processed_data" / "loan_applications_predict_enriched.csv"
    )
    # We must use the same columns the model was trained on
    numeric_cols = list(constants.NUMERIC_MODELLING_COLUMNS) + list(constants.ENGINEERED_NUMERIC_COLUMNS)
    categorical_cols = list(constants.CATEGORICAL_MODELLING_COLUMNS) + list(constants.ENGINEERED_CATEGORICAL_COLUMNS)
    X_pred = predict_enriched[numeric_cols + categorical_cols]
    
    scores = champion.predict_proba(X_pred)[:, 1]
    out = predict_enriched[["application_id"]].copy()
    out["default_probability"] = scores
    out.to_csv(base / "output" / "champion_predictions.csv", index=False)
    print("Wrote output/champion_predictions.csv")
    
    # 3. Write champion importances
    importances = feature_importances(champion)
    importances.to_csv(base / "output" / "champion_importances.csv", index=False)
    print("Wrote output/champion_importances.csv")


if __name__ == "__main__":
    run()
