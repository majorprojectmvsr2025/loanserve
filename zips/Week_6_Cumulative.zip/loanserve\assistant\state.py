"""loanserve/assistant/state.py — Week 7 Day 5"""
import operator
from typing import Annotated, TypedDict
from langgraph.graph.message import add_messages


class AssistantState(TypedDict, total=False):
    """State carried through the assistant's nodes."""
    question: str
    category: str
    urgency: str
    refused: bool
    plan: list[dict]
    draft: str
    needs_approval: bool
    messages: Annotated[list, add_messages]
    steps: Annotated[list[str], operator.add]


def new_assistant_state(question: str) -> AssistantState:
    """Return a fresh state dictionary for a new question."""
    return {
        "question": question,
        "category": "",
        "urgency": "",
        "refused": False,
        "plan": [],
        "draft": "",
        "needs_approval": False,
        "messages": [],
        "steps": []
    }
