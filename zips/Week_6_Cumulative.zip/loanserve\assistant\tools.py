"""loanserve/assistant/tools.py — Week 7 Day 4"""
import joblib
import pandas as pd
from pathlib import Path
from loanserve.core.loan_calculations import calculate_monthly_installment
from loanserve.data_access.database_loader import ApplicationDatabase
from loanserve.retrieval.filtered_search import filtered_search
from loanserve.retrieval.vector_store import open_policy_store, load_embedder

class ToolError(Exception):
    pass


def calculate_installment(args: dict) -> dict:
    """Calculate the monthly installment for a loan."""
    principal = args.get("principal_inr")
    rate = args.get("annual_interest_rate_percent")
    tenure = args.get("tenure_months")
    
    if principal is None or rate is None or tenure is None:
        raise ToolError("Missing required arguments for calculation.")
        
    if principal <= 0 or tenure <= 0 or rate < 0:
        raise ToolError("Invalid arguments for loan calculation.")
        
    ans = calculate_monthly_installment(principal, rate, tenure)
    return {"monthly_installment_inr": round(ans, 2)}


def lookup_application(args: dict, database_path: Path | str) -> dict:
    """Look up an application by ID."""
    app_id = args.get("application_id")
    if not app_id:
        raise ToolError("application_id is missing.")
        
    db = ApplicationDatabase(database_path)
    record = db.find_application(app_id.upper())
    if not record:
        raise ToolError(f"Application {app_id} not found.")
        
    return dict(record)


def predict_default_risk(args: dict, champion_path: Path | str) -> dict:
    """Score an application with the champion model."""
    app = args.get("application")
    if not app:
        raise ToolError("application dictionary is missing.")
        
    try:
        model = joblib.load(champion_path)
        df = pd.DataFrame([app])
        # The champion pipeline expects certain columns
        proba = model.predict_proba(df)[0, 1]
    except Exception as exc:
        raise ToolError(f"Model prediction failed: {exc}")
        
    return {"default_probability": float(proba)}


def search_policy_documents(args: dict, store_path: Path | str) -> dict:
    """Search policy documents for the given question."""
    question = args.get("question")
    how_many = args.get("how_many", 3)
    
    if not question or len(question.strip()) < 5:
        raise ToolError("A meaningful question is required.")
        
    if how_many > 10:
        raise ToolError(f"Requested {how_many} passages, which is too many.")
        
    try:
        collection = open_policy_store(store_path)
        embedder = load_embedder()
        found = filtered_search(collection, question, embedder, how_many)
    except Exception as exc:
        raise ToolError(f"Search failed: {exc}")
        
    return {"passages": found}
