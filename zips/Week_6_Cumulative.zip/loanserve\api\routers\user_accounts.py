"""loanserve/api/routers/user_accounts.py — Week 3 Day 4

Signup and login routes. User accounts are stored in-memory per service instance
(the tests create a fresh service per test, so persistence is not required).
"""
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from loanserve.api.password_hashing import PasswordVault

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])

_vault = PasswordVault()

_VALID_ROLES = {"loan_officer", "administrator"}


class _SignupRequest(BaseModel):
    user_name: str
    password: str = Field(min_length=8)
    role: str


class _LoginRequest(BaseModel):
    user_name: str
    password: str


def _get_user_store(request: Request) -> dict:
    return request.app.state.user_store


@router.post("/signup", status_code=201)
def signup_route(body: _SignupRequest, request: Request):
    store = _get_user_store(request)
    if body.user_name in store:
        raise HTTPException(status_code=409, detail="Username already taken.")
    if body.role not in _VALID_ROLES:
        raise HTTPException(
            status_code=422, detail=f"Role must be one of {sorted(_VALID_ROLES)}."
        )
    store[body.user_name] = {
        "hashed_password": _vault.hash_password(body.password),
        "role": body.role,
    }
    return {"user_name": body.user_name, "role": body.role}


@router.post("/login")
def login_route(body: _LoginRequest, request: Request):
    store = _get_user_store(request)
    guard = request.app.state.access_control
    entry = store.get(body.user_name)
    if entry is None or not _vault.matches_stored_hash(body.password,
                                                       entry["hashed_password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials.")
    token = guard.issue_token(body.user_name, entry["role"])
    guard.record_audit_entry(body.user_name, "login")
    return {"access_token": token}
