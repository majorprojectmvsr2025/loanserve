"""loanserve/api/routers/loan_applications.py — Week 2 D4, D5, Week 3 D1-4"""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field

from loanserve.api.schemas import LoanApplicationRequest, LoanApplicationResponse
from loanserve.core.entities import create_loan_application
from loanserve.core.exceptions import LoanServeError
from loanserve.core.loan_calculations import build_outstanding_balances

router = APIRouter(prefix="/api/v1/applications", tags=["applications"])


def _get_repo(request: Request):
    return request.app.state.application_repository


def _get_guard(request: Request):
    return request.app.state.access_control


def _open_mode(request: Request) -> bool:
    import os
    return os.environ.get("LOANSERVE_OPEN_MODE") == "1"


def _require_auth(request: Request):
    """Authenticate request; skip when LOANSERVE_OPEN_MODE=1."""
    if _open_mode(request):
        return {"sub": "open", "role": "administrator"}
    guard = _get_guard(request)
    return guard.authorise(request)


def _build_response(record: dict) -> LoanApplicationResponse:
    """Build a LoanApplicationResponse from a stored record dict."""
    application = create_loan_application(record)
    return LoanApplicationResponse(
        application_id=record["application_id"],
        applicant_name=record.get("applicant_name", ""),
        loan_type=application.loan_type,
        loan_amount_inr=application.principal_inr,
        tenure_months=application.tenure_months,
        interest_rate_percent=application.interest_rate_percent(),
        monthly_installment_inr=round(application.monthly_installment_inr(), 2),
        is_eligible=application.is_eligible(),
        rejection_reasons=application.rejection_reasons(),
    )


class _ListParams(BaseModel):
    loan_type: Optional[str] = None
    limit: int = Field(default=20, le=100)
    offset: int = 0


@router.post("", status_code=201)
def create_application_route(
    body: LoanApplicationRequest,
    request: Request,
    _claims: dict = Depends(_require_auth),
):
    repo = _get_repo(request)
    try:
        record = repo.save_application(body.model_dump())
        return _build_response(record)
    except LoanServeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("")
def list_applications_route(
    request: Request,
    loan_type: Optional[str] = None,
    limit: int = 20,
    offset: int = 0,
    _claims: dict = Depends(_require_auth),
):
    if limit > 100:
        raise HTTPException(status_code=422, detail="limit may not exceed 100.")
    repo = _get_repo(request)
    applications, total = repo.list_applications(loan_type, limit, offset)
    try:
        return {
            "total": total,
            "applications": [_build_response(r) for r in applications],
        }
    except LoanServeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/{application_id}")
def get_application_route(
    application_id: str,
    request: Request,
    _claims: dict = Depends(_require_auth),
):
    repo = _get_repo(request)
    record = repo.find_application(application_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"{application_id} not found.")
    try:
        return _build_response(record)
    except LoanServeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/{application_id}/schedule")
def schedule_route(
    application_id: str,
    request: Request,
    _claims: dict = Depends(_require_auth),
):
    repo = _get_repo(request)
    record = repo.find_application(application_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"{application_id} not found.")
    try:
        application = create_loan_application(record)
    except LoanServeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    balances = build_outstanding_balances(
        application.principal_inr,
        application.interest_rate_percent(),
        application.tenure_months,
    )
    return {
        "application_id": application_id,
        "outstanding_after_each_month": [round(float(b), 2) for b in balances],
    }


@router.put("/{application_id}")
def replace_application_route(
    application_id: str,
    body: LoanApplicationRequest,
    request: Request,
    _claims: dict = Depends(_require_auth),
):
    repo = _get_repo(request)
    record = repo.replace_application(application_id, body.model_dump())
    if record is None:
        raise HTTPException(status_code=404, detail=f"{application_id} not found.")
    try:
        return _build_response(record)
    except LoanServeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.delete("/{application_id}", status_code=204)
def delete_application_route(
    application_id: str,
    request: Request,
    claims: dict = Depends(_require_auth),
):
    # Role check: only administrators may delete
    if not _open_mode(request):
        guard = _get_guard(request)
        if claims.get("role") != "administrator":
            raise HTTPException(status_code=403, detail="Administrators only.")
    repo = _get_repo(request)
    deleted = repo.delete_application(application_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"{application_id} not found.")
    return Response(status_code=204)
