"""scripts/day02_loan_pricing.py — Week 1 Day 2

Standalone pricing functions and a LoanApplication entity class.
Imported directly from scripts/ directory by the tests.
"""

# ---------------------------------------------------------------------------
# Product catalogue
# ---------------------------------------------------------------------------

LOAN_PRODUCTS = {
    "home":     {"rate": 8.50,  "max_amount": 15_000_000},
    "vehicle":  {"rate": 9.75,  "max_amount":  2_000_000},
    "gold":     {"rate": 11.00, "max_amount":  1_500_000},
    "personal": {"rate": 14.50, "max_amount":  1_500_000},
}

MINIMUM_AGE = 21
MAXIMUM_AGE = 60
MAXIMUM_DTI = 0.50


# ---------------------------------------------------------------------------
# Pure calculation functions
# ---------------------------------------------------------------------------

def calculate_monthly_installment(principal: float, annual_rate: float,
                                   tenure_months: int) -> float:
    """Standard EMI formula; handles zero interest."""
    if annual_rate == 0.0:
        return principal / tenure_months
    r = annual_rate / 100 / 12
    factor = (1 + r) ** tenure_months
    return principal * r * factor / (factor - 1)


def calculate_debt_to_income_ratio(monthly_installment: float,
                                    monthly_income: float) -> float:
    return monthly_installment / monthly_income


# ---------------------------------------------------------------------------
# LoanApplication entity
# ---------------------------------------------------------------------------

class LoanApplication:
    """Encapsulates a single loan application and all eligibility logic."""

    def __init__(self, record: dict):
        loan_type_raw = record.get("loan_type", "")
        loan_type = loan_type_raw.lower()

        product = LOAN_PRODUCTS.get(loan_type)
        if product is None:
            self._unsupported = loan_type_raw
        else:
            self._unsupported = None

        self.loan_type = loan_type
        self.principal_inr = float(record.get("loan_amount_inr", 0))
        self.tenure_months = int(record.get("tenure_months", 0))
        self.monthly_income_inr = float(record.get("monthly_income_inr", 0))
        self.age_years = int(record.get("age_years", 0))
        self._product = product

    def interest_rate_percent(self) -> float:
        if self._product is None:
            return 0.0
        return self._product["rate"]

    def monthly_installment_inr(self) -> float:
        return calculate_monthly_installment(
            self.principal_inr,
            self.interest_rate_percent(),
            self.tenure_months,
        )

    def rejection_reasons(self) -> list:
        reasons = []

        if self._unsupported is not None:
            reasons.append(
                f"Loan type '{self._unsupported}' is not offered by LoanServe."
            )
            return reasons  # can't check other rules without a product

        # Age rule
        if self.age_years < MINIMUM_AGE or self.age_years > MAXIMUM_AGE:
            reasons.append(
                f"Applicant age {self.age_years} is outside the permitted range "
                f"of {MINIMUM_AGE}–{MAXIMUM_AGE} years."
            )

        # Affordability rule
        dti = calculate_debt_to_income_ratio(
            self.monthly_installment_inr(), self.monthly_income_inr)
        if dti > MAXIMUM_DTI:
            reasons.append(
                f"Debt-to-income {dti:.2f} exceeds {MAXIMUM_DTI:.2f}."
            )

        # Product cap
        if self.principal_inr > self._product["max_amount"]:
            reasons.append(
                f"Loan amount {self.principal_inr:,.2f} exceeds the "
                f"{self.loan_type} cap of {self._product['max_amount']:,.2f}."
            )

        return reasons

    def is_eligible(self) -> bool:
        return len(self.rejection_reasons()) == 0
    #hello checking if this is working or not.